<?php
// echo __DIR__;

header('location:public/');
