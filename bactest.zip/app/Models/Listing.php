<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Listing extends Model
{
    use HasFactory;

    protected $fillable = [
        'package_id',
        'room_type',
        'price',
        'description',
        'image',
        'taxi_driver_name',
        'taxi_driver_mobile',
        'car_rental_type',
        'flight_departure',
        'flight_type',
        'flight_arrival',
        'flight_to',
        'flight_from',
        // 'flight_international_to',
        // 'flight_international_from',
        'flight_international',
    ];

    public function package()
    {
        return  $this->belongsTo(package::class);
    }

    public function to()
    {
        return  $this->belongsTo(District::class, 'flight_to');
    }

    public function ito()
    {
        return  $this->belongsTo(Country::class, 'flight_to');
    }

    public function from()
    {
        return  $this->belongsTo(District::class, 'flight_from');
    }

    public function ifrom()
    {
        return  $this->belongsTo(Country::class, 'flight_from');
    }


    
}
