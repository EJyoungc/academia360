<?php

namespace App\Http\Livewire;

use App\Models\Category;
use App\Models\Listing;
use App\Models\Package;
use App\Models\user;
use App\Models\User as ModelsUser;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Storage;
use Jantinnerezo\LivewireAlert\LivewireAlert;
use Livewire\Component;
use Livewire\WithFileUploads;

class Users extends Component
{
    use LivewireAlert;
    use WithFileUploads;
    public
        $users = [],
        $role = [],
        $mobile,
        $name,
        $email,
        $password = 'hell0W0rld!',
        $user,
        $search,
        $show_map = false,
        $modal = false,
        $modal2 = false;

    protected $listeners = [
        'delete'
    ];

    public function  deleteit($data)
    {
        $this->user = $data;
        $this->alert('warning', 'Are You Sure You Want to Delete ? ', [
            'position' => 'center',
            'toast' => false,
            'timer' => null,
            'popup' => true,
            'backdrop' => true,
            'text' => null,
            'showCancelButton' => true,
            'onConfirmed' => 'delete',
            'showConfirmButton' => true,
            'confirmButtonText' => 'Delete'
        ]);
    }

    public function query()
    {
        $this->users =
            ModelsUser::whereLike(['role', 'mobile', 'name', 'email',], $this->search ?? '')
            ->get();
        // $this->users = Listing::whereLike(['id', 'district.name', 'user_type', 'mobile', 'description', 'package.name',], $this->search ?? '')->get();
    }
    public function create()
    {

        $this->modal = true;
    }
    public function cancel()
    {

        $this->resetExcept(['users']);
    }

    public function delete()
    {
        $r = Listing::find($this->user);
        Storage::delete($r->email);
        $r->delete();
        $this->show();
        $this->resetExcept('users', 'role');
        $this->alert('success', 'Successfully deleted user!');
    }

    public function edit($user)
    {
        $r = ModelsUser::find($user);
        $this->user = $user;
        $this->role = $r->role;
        $this->mobile = $r->mobile;
        $this->email = $r->email;
        $this->password = '';
        $this->name = $r->name;
        $this->modal2 = true;
    }

    public function show()
    {


        $this->users = ModelsUser::all();
    }

    public function mount()
    {
        $this->show();
    }

    public function update()
    {

        if (!empty($this->password)) {
            $this->validate([
                'role' => 'required|string',
                'mobile' => 'required|numeric',
                'email' => 'required|email',
                'name' => 'required|string',
                'password' => 'required|string',

            ]);

            $r = ModelsUser::find($this->user);

            $r->name = $this->name;
            $r->email = $this->email;
            $r->role = $this->role;
            $r->password = Hash::make($this->password);
            $r->mobile = $this->mobile;
            $r->save();
            $this->show();
            $this->resetExcept('users');
            $this->alert('success', 'Successfully Update user!');
        } else {
            $this->validate([
                'role' => 'required|string',
                'mobile' => 'required|numeric',
                'email' => 'required|email',
                'name' => 'required|string',


            ]);

            $r = ModelsUser::find($this->user);
            $r->name = $this->name;
            $r->email = $this->email;
            $r->role = $this->role;

            $r->mobile = $this->mobile;
            $r->save();
            $this->show();
            $this->resetExcept('users');
        }
    }


    public function store()
    {
        $this->validate([
            'role' => 'required|string',
            'mobile' => 'required|numeric',
            'email' => 'required|email|unique:users,email',
            'name' => 'required|string',
            'password' => 'required|string',

        ]);



        $r = new ModelsUser();

        $r->name = $this->name;
        $r->email = $this->email;
        $r->role = $this->role;
        $r->password = Hash::make($this->password);
        $r->mobile = $this->mobile;
        $r->save();
        $this->show();
        $this->resetExcept('users');
        $this->alert('success', 'Successfully added user!');
    }


    public function render()
    {
        return view('livewire.users', [
            'users' => $this->users,

        ]);
    }
}
