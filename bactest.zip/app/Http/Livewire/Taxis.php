<?php

namespace App\Http\Livewire;

use App\Models\Listing;
use App\Models\Package;
use Jantinnerezo\LivewireAlert\LivewireAlert;
use Livewire\Component;
use Livewire\WithFileUploads;

class Taxis extends Component
{
    use LivewireAlert;
    use WithFileUploads;
    public
        $taxis = [],
        $categories = [],
        $package,
        $description,
        $packages = [],
        $price,
        $driver_name,
        $driver_mobile,
        $taxi,
        $search,
        $show_map = false,
        $modal = false,
        $modal2 = false;

    protected $listeners = [
        'delete'
    ];

    public function  deleteit($data)
    {
        $this->taxi = $data;
        $this->alert('warning', 'Are You Sure You Want to Delete ? ', [
            'position' => 'center',
            'toast' => false,
            'timer' => null,
            'popup' => true,
            'backdrop' => true,
            'text' => null,
            'showCancelButton' => true,
            'onConfirmed' => 'delete',
            'showConfirmButton' => true,
            'confirmButtonText' => 'Delete'
        ]);
    }

    public function query()
    {
        $this->taxis =
            Listing::join('packages', 'package_id', 'packages.id')
            ->join('categories', 'category_id', '=', 'categories.id')
            ->where('categories.id', '=', '4')
            ->whereLike(['taxi_driver_name', 'taxi_driver_mobile', 'price', 'package.name',], $this->search ?? '')
            ->select('listings.*')
            ->get();
        // $this->taxis = Listing::whereLike(['id', 'taxi_driver_name', 'taxi_driver_mobile', 'price', 'description', 'package.name',], $this->search ?? '')->get();
    }
    public function create()
    {

        $this->modal = true;
    }
    public function cancel()
    {

        $this->resetExcept(['taxis', 'packages']);
    }

    public function delete()
    {
        $r = Listing::find($this->taxi);
        $r->delete();
        $this->show();
        $this->resetExcept('taxis', 'packages');
        $this->alert('success', 'Successfully deleted taxi!');
    }

    public function edit($taxi)
    {
        $r = Listing::find($taxi);
        $this->taxi = $taxi;
        $this->driver_name = $r->taxi_driver_name;
        $this->driver_mobile = $r->taxi_driver_mobile;
        $this->price = $r->price;
        $this->package = $r->package_id;
        $this->description = $r->description;
        $this->modal2 = true;
    }

    public function show()
    {

        $this->packages = Package::where('category_id', '4')->get();
        $this->taxis =
            Listing::join('packages', 'package_id', 'packages.id')
            ->join('categories', 'category_id', '=', 'categories.id')
            ->where('categories.id', '=', '4')
            ->select('listings.*')
            ->get();
    }

    public function mount()
    {
        $this->show();
    }

    public function update()
    {

        $this->validate([
            'driver_name' => 'required|string',
            'price' => 'required|numeric',
            'package' => 'required',
            'description' => 'required',
            'driver_mobile' => 'required|numeric'

        ]);
        $l = Listing::find($this->taxi);
        $l->taxi_driver_name = $this->driver_name;
        $l->package_id = $this->package;
        $l->price = $this->price;
        $l->description = $this->description;
        $l->taxi_driver_mobile = $this->driver_mobile;
        $l->save();
        $this->show();
        $this->resetExcept('taxis', 'packages');
        $this->alert('success', 'Successfully Update taxi!');
    }


    public function store()
    {
        $this->validate([
            'driver_name' => 'required|string',
            'price' => 'required|numeric',
            'package' => 'required',
            'description' => 'required',
            'driver_mobile' => 'required|numeric'

        ]);

        $l = new Listing();
        $l->taxi_driver_name = $this->driver_name;
        $l->taxi_driver_mobile = $this->driver_mobile;
        $l->price = $this->price;
        $l->package_id = $this->package;
        $l->description = $this->description;
        $l->save();
        $this->show();
        $this->resetExcept(['taxis']);
        $this->alert('success', 'Successfully added taxi!');
    }


    public function render()
    {
        return view('livewire.taxis');
    }
}
