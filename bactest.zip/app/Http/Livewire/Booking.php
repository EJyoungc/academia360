<?php

namespace App\Http\Livewire;

use App\Models\Booking as ModelsBooking;
use App\Models\Listing;
use App\Models\Package;
use Illuminate\Support\Facades\Storage;
use Jantinnerezo\LivewireAlert\LivewireAlert;
use Livewire\Component;
use Livewire\WithFileUploads;

class Booking extends Component
{

    use LivewireAlert;
    use WithFileUploads;
    public
        $rooms = [],
        $categories = [],
        $package,
        $description,
        $packages = [],
        $price,
        $type,
        $image,
        $room,
        $search,
        $show_map = false,
        $modal = false,
        $modal2 = false;

    protected $listeners = [
        'delete'
    ];

    public function  deleteit($data)
    {
        $this->room = $data;
        $this->alert('warning', 'Are You Sure You Want to Delete ? ', [
            'position' => 'center',
            'toast' => false,
            'timer' => null,
            'popup' => true,
            'backdrop' => true,
            'text' => null,
            'showCancelButton' => true,
            'onConfirmed' => 'delete',
            'showConfirmButton' => true,
            'confirmButtonText' => 'Delete'
        ]);
    }

    public function query()
    {
        $this->rooms =
            Listing::join('packages', 'package_id', 'packages.id')
            ->join('categories', 'category_id', '=', 'categories.id')
            ->where('categories.id', '=', '1')
            ->whereLike(['room_type', 'price', 'package.name',], $this->search ?? '')
            ->select('listings.*')
            ->get();
        // $this->rooms = Listing::whereLike(['id', 'district.name', 'room_type', 'price', 'description', 'package.name',], $this->search ?? '')->get();
    }
    public function create()
    {

        $this->modal = true;
    }
    public function cancel()
    {

        $this->resetExcept(['rooms', 'packages']);
    }

    public function delete()
    {
        $r = Listing::find($this->room);
        Storage::delete($r->image);
        $r->delete();
        $this->show();
        $this->resetExcept('rooms', 'packages');
        $this->alert('success', 'Successfully deleted room!');
    }

    public function edit($room)
    {
        $r = Listing::find($room);
        $this->room = $room;
        $this->type = $r->room_type;
        $this->price = $r->price;
        $this->package = $r->package_id;
        $this->description = $r->description;
        $this->modal2 = true;
    }

    public function show()
    {

        $this->packages = Package::where('category_id', '1')->get();
        $this->rooms = ModelsBooking::all();
    }

    public function mount()
    {
        $this->show();
    }

    public function update()
    {

        if ($this->image == "") {
            $this->validate([
                'type' => 'required|string',
                'price' => 'required|numeric',
                'package' => 'required',
                'description' => 'required',
                // 'image' => 'required|mimes:jpg,png,jpeg'

            ]);

            $r = Listing::find($this->room);

            $r->room_type = $this->type;
            $r->price = $this->price;
            $r->package_id = $this->package;
            $r->description = $this->description;
            $r->save();
            $this->show();
            $this->resetExcept('rooms', 'packages');
            $this->alert('success', 'Successfully Update room!');
        } else {
            $this->validate([
                'type' => 'required|string',
                'price' => 'required|numeric',
                'package' => 'required',
                'description' => 'required',
                'image' => 'required|mimes:jpg,png,jpeg'

            ]);
            $l = Listing::find($this->room);
            Storage::delete($l->image);
            $file = $this->image->store('images');
            $l->room_type = $this->type;
            $l->price = $this->price;
            $l->package_id = $this->package;
            $l->description = $this->description;
            $l->image = $file;
            $l->save();
            $this->show();
            $this->resetExcept('rooms', 'packages');
            $this->alert('success', 'Successfully Update room!');
        }
    }


    public function store()
    {
        $this->validate([
            'type' => 'required|string',
            'price' => 'required|numeric',
            'package' => 'required',
            'description' => 'required',
            'image' => 'required|mimes:jpg,png,jpeg'

        ]);




        $file = $this->image->store('images');

        $l = new Listing();
        $l->room_type = $this->type;
        $l->price = $this->price;
        $l->package_id = $this->package;
        $l->description = $this->description;
        $l->image = $file;
        $l->save();
        $this->show();
        $this->resetExcept(['rooms']);
        $this->alert('success', 'Successfully added room!');
    }
    public function render()
    {
        return view('livewire.booking');
    }
}
