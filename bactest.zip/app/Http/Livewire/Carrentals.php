<?php

namespace App\Http\Livewire;

use App\Models\Listing;
use App\Models\Package;
use Illuminate\Support\Facades\Storage;
use Jantinnerezo\LivewireAlert\LivewireAlert;
use Livewire\Component;
use Livewire\WithFileUploads;

class Carrentals extends Component
{

    use LivewireAlert;
    use WithFileUploads;
    public
        $carrentals = [],
        $categories = [],
        $package,
        $description,
        $packages = [],
        $price,
        $type,
        $image,
        $carrental,
        $search,
        $show_map = false,
        $modal = false,
        $modal2 = false;

    protected $listeners = [
        'delete'
    ];

    public function  deleteit($data)
    {
        $this->carrental = $data;
        $this->alert('warning', 'Are You Sure You Want to Delete ? ', [
            'position' => 'center',
            'toast' => false,
            'timer' => null,
            'popup' => true,
            'backdrop' => true,
            'text' => null,
            'showCancelButton' => true,
            'onConfirmed' => 'delete',
            'showConfirmButton' => true,
            'confirmButtonText' => 'Delete'
        ]);
    }

    public function query()
    {
        $this->carrentals =
            Listing::join('packages', 'package_id', 'packages.id')
            ->join('categories', 'category_id', '=', 'categories.id')
            ->where('categories.id', '=', '5')
            ->whereLike(['car_rental_type', 'price', 'package.name',], $this->search ?? '')
            ->select('listings.*')
            ->get();
        // $this->carrentals = Listing::whereLike(['id', 'district.name', 'carrental_type', 'price', 'description', 'package.name',], $this->search ?? '')->get();
    }
    public function create()
    {

        $this->modal = true;
    }
    public function cancel()
    {

        $this->resetExcept(['carrentals', 'packages']);
    }

    public function delete()
    {
        $r = Listing::find($this->carrental);
        Storage::delete($r->image);
        $r->delete();
        $this->show();
        $this->resetExcept('carrentals', 'packages');
        $this->alert('success', 'Successfully deleted carrental!');
    }

    public function edit($carrental)
    {
        $r = Listing::find($carrental);
        $this->carrental = $carrental;
        $this->type = $r->car_rental_type;
        $this->price = $r->price;
        $this->package = $r->package_id;
        $this->description = $r->description;
        $this->modal2 = true;
    }

    public function show()
    {

        $this->packages = Package::where('category_id', '5')->get();
        $this->carrentals =
            Listing::join('packages', 'package_id', 'packages.id')
            ->join('categories', 'category_id', '=', 'categories.id')
            ->where('categories.id', '=', '5')
            ->select('listings.*')
            ->get();
    }

    public function mount()
    {
        $this->show();
    }

    public function update()
    {

        if ($this->image == "") {
            $this->validate([
                'type' => 'required|string',
                'price' => 'required|numeric',
                'package' => 'required',
                'description' => 'required',
                // 'image' => 'required|mimes:jpg,png,jpeg'

            ]);

            $r = Listing::find($this->carrental);

            $r->car_rental_type = $this->type;
            $r->price = $this->price;
            $r->package_id = $this->package;
            $r->description = $this->description;
            $r->save();
            $this->show();
            $this->resetExcept('carrentals', 'packages');
            $this->alert('success', 'Successfully Update carrental!');
        } else {
            $this->validate([
                'type' => 'required|string',
                'price' => 'required|numeric',
                'package' => 'required',
                'description' => 'required',
                'image' => 'required|mimes:jpg,png,jpeg'

            ]);
            $l = Listing::find($this->carrental);
            Storage::delete($l->image);
            $file = $this->image->store('images');
            $l->car_rental_type = $this->type;
            $l->price = $this->price;
            $l->package_id = $this->package;
            $l->description = $this->description;
            $l->image = $file;
            $l->save();
            $this->show();
            $this->resetExcept('carrentals', 'packages');
            $this->alert('success', 'Successfully Update carrental!');
        }
    }


    public function store()
    {
        $this->validate([
            'type' => 'required|string',
            'price' => 'required|numeric',
            'package' => 'required',
            'description' => 'required',
            'image' => 'required|mimes:jpg,png,jpeg'

        ]);




        $file = $this->image->store('images');

        $l = new Listing();
        $l->car_rental_type = $this->type;
        $l->price = $this->price;
        $l->package_id = $this->package;
        $l->description = $this->description;
        $l->image = $file;
        $l->save();
        $this->show();
        $this->resetExcept(['carrentals']);
        $this->alert('success', 'Successfully added carrental!');
    }


    public function render()
    {
        return view('livewire.carrentals');
    }
}
