<?php

namespace App\Http\Livewire;

use App\Models\User;
use Illuminate\Support\Facades\Auth;
use Jantinnerezo\LivewireAlert\LivewireAlert;
use Livewire\Component;

class UpdateProfileMobile extends Component
{
    public $mobile;
    use LivewireAlert;
    public $mobileE;

    public function mount()
    {
        $this->mobile = Auth::user()->mobile;
        if (Auth::user()->mobile == '') {
            $this->mobileE = "Please Add a Valid Phone number !";
        }
    }



    public function update()
    {
        $this->validate([
            'mobile' => 'required|numeric'
        ]);

        $user = User::find(Auth::user()->id);

        $user->mobile = $this->mobile;
        $user->save();
        $this->alert('success', 'successfully updated mobile number');
        $this->mobileE = '';
    }

    public function render()
    {

        return view('livewire.update-profile-mobile');
    }
}
