<?php

namespace App\Http\Livewire\Public\Carrentals;

use App\Models\Listing;
use App\Models\Package;
use Livewire\Component;

class Showcarrentals extends Component
{

    public $search = '';
    public $package;
    public $did;
    public function mount($id)
    {
        $this->did = $id;
        $this->package = Package::find($id);
        // dd($id, $this->listings);
    }



    public function render()
    {
        return view('livewire.public.carrentals.showcarrentals', [
            'listings' => Listing::where('package_id', $this->did)
                ->whereLike(['car_rental_type', 'price', 'package.name',], $this->search ?? '')
                // ->select('listings.*')
                ->get(),
        ])->layout('layouts.root3');
    }
}
