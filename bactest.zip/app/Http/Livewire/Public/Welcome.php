<?php

namespace App\Http\Livewire\Public;

use App\Http\Livewire\Packages;
use App\Models\Package;
use Illuminate\Support\Facades\DB;
use Livewire\Component;

class Welcome extends Component
{
    public
        $results = [],
        $dropdown = false,
        $location;


    public function query()
    {
        if (!empty($this->location)) {
            $this->dropdown = true;
        } else {
            $this->dropdown = false;
        }
        $results = Package::join('locations', 'locations.package_id', '=', 'packages.id')
            ->join('categories', 'categories.id', '=', 'packages.category_id')
            ->join('images', 'images.package_id', '=', 'packages.id')
            ->where('locations.coordinates', 'like', '%' . $this->location . '%')
            ->orWhere('categories.name', 'like', '%' . $this->location . '%')
            ->select('packages.name', 'images.image', 'packages.description', 'packages.price', 'locations.coordinates', 'categories.name AS category')
            ->get();
        $this->results = $results;
        // dd($results);


        $this->results =  Package::where('name', 'like', '%' . $this->location . '%')->get();
    }

    public function render()
    {
        return view('livewire.public.welcome');
    }
}
