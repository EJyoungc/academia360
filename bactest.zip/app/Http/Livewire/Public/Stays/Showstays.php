<?php

namespace App\Http\Livewire\Public\Stays;

use App\Models\Listing;
use App\Models\Package;
use Livewire\Component;
use Livewire\WithPagination;

class Showstays extends Component
{

    use WithPagination;
    // public $listings = [];
    public $package;
    public $did;
    public $search = '';


    public function mount($id)
    {
        $this->package = Package::find($id);

        $this->did = $id;
        // $this->listings = Listing::where('package_id', $id)->get();
        //  dd($id, $this);
    }


    public function render()
    {

        return view('livewire.public.stays.showstays', [
            'listings' => Listing::where('package_id', $this->did)
                ->whereLike(['room_type', 'price', 'package.name',], $this->search ?? '')
                // ->select('listings.*')
                ->get(),
        ])->layout('layouts.root3');
    }
}
