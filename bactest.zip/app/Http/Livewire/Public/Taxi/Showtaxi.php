<?php

namespace App\Http\Livewire\Public\Taxi;

use App\Models\Listing;
use App\Models\Package;
use Livewire\Component;

class Showtaxi extends Component
{


    public $package = [];
    public $did;
    public $search;
    public function mount($id)
    {
        $this->package = Package::find($id);

        $this->did = $id ;
        // dd($id, $this->listings);
    }


    public function render()
    {
        return view('livewire.public.taxi.showtaxi',[
            'listings'=>Listing::where('package_id', $this->did)
            ->whereLike(['taxi_driver_name', 'taxi_driver_mobile', 'price', 'package.name',], $this->search ?? '')->get(),
        ])->layout('layouts.root3');
    }
}
