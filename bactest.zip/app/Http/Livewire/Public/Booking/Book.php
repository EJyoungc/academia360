<?php

namespace App\Http\Livewire\Public\Booking;

use App\Models\Listing;
use Livewire\Component;

class Book extends Component
{
    public
        $paid = false,
        $data,
        $listing,
        $payattempt = false;


    public function mount($id)
    {
        // $this->data = $id;
        $this->listing = Listing::find($id);
    }

    public function pay()
    {
        $this->payattempt = true;
        $this->paid = true;
    }

    public function render()
    {

        return view('livewire.public.booking.book')->layout('layouts.root3');
    }
}
