<?php

namespace App\Http\Livewire\Public\Attractions;

use App\Models\Listing;
use App\Models\Package;
use Livewire\Component;

class Showattractions extends Component
{

    public
        $did,
        $package,
        $search;

    public function mount($id)
    {
        $this->package = Package::find($id);
        // $this->listings = Listing::where('package_id', $id)->get();
        $this->did = $id;
    }


    public function render()
    {
        return view('livewire.public.attractions.showattractions', [
            'listings' => Listing::where('package_id', $this->did)
                ->whereLike(['car_rental_type', 'price', 'package.name',], $this->search ?? '')
                // ->select('listings.*')
                ->get(),
        ])->layout('layouts.root3');
    }
}
