<?php

namespace App\Http\Livewire;

use Jantinnerezo\LivewireAlert\LivewireAlert;
use App\Models\Category;
use Livewire\Component;

class Categories extends Component
{

    use LivewireAlert;
    public
        $categories = [],
        $ccount = 0,
        $Name,
        $did,
        $search,
        $category,
        $modal = false,
        $modal2 = false;
    protected $listeners = [
        'delete'
    ];

    public function  deleteit($data)
    {
        $this->category = $data;
        $this->alert('warning', 'Are You Sure You Want to Delete ? ', [
            'position' => 'center',
            'toast' => false,
            'timer' => null,
            'popup' => true,
            'backdrop' => true,
            'text' => null,
            'showCancelButton' => true,
            'onConfirmed' => 'delete',
            'showConfirmButton' => true,
            'confirmButtonText' => 'Delete'
        ]);
    }

    public function query()
    {
        // if ($this->search)
        $this->categories =  Category::whereLike(['name', 'id'], $this->search ?? '')->get();
    }
    public function createmodal()
    {
        $this->modal = true;
    }
    public function edit($did)
    {
        // dd($did);
        $category =  Category::find($did);
        $this->Name =  $category->name;
        $this->did = $category->id;
        $this->modal2 = true;
    }

    public function delete()
    {


        $d = Category::find($this->category);
        $d->delete();

        $this->alert('success', 'Succefully deleted Category');
        $this->show();
        $this->resetExcept('categories');
    }

    public function cancel()
    {
        $this->modal2 = false;
        $this->modal = false;
        $this->resetExcept('categories');
    }


    public function store()
    {

        $validatedData = $this->validate([
            "Name" => "required"
        ]);
        // dd($this->Name);


        Category::create([
            'name' => $this->Name
        ]);

        $this->show();
        $this->resetExcept(['categories']);
        // $this->cancel();
        $this->alert('success', 'Successully added category!');
    }

    public function update()
    {
        $d = Category::find($this->did);
        $validatedData = $this->validate([
            'Name' => 'required'
        ]);

        $d->name = $this->Name;
        $d->save();

        $this->alert('success', 'Successfully updated category!');
        $this->show();
        $this->cancel();
    }

    public function show()
    {
        $this->ccount = Category::all()->count();
        $this->categories = Category::all();
    }
    public function mount()
    {

        $this->show();
    }


    public function render()
    {
        return view('livewire.categories', ['categories' => $this->categories]);
    }
}
