<?php

namespace App\Http\Livewire\Components;

use App\Http\Livewire\Packages;
use App\Models\Listing;
use App\Models\Package;
use Livewire\Component;
use Livewire\WithPagination;

class PublicStays extends Component
{

    use WithPagination;
    public $listings = [];

    public $search = '';

    public function updatingSearch()
    {
        $this->resetPage();
    }

    protected $paginationTheme = 'bootstrap';
    


    public function render()
    {
        return view('livewire.components.public-stays', [
            'packages' => Package::whereLike([
                'category.name',
                'name',
                'description',
                'district.name'
            ], $this->search ?? '')->where('category_id', '1')->paginate(6),
        ]);
    }
}
