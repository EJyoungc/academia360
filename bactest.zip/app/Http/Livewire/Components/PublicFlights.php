<?php

namespace App\Http\Livewire\Components;

use App\Models\Package;
use Livewire\Component;
use Livewire\WithPagination;

class PublicFlights extends Component
{
    use WithPagination;

    public $search = '';

    public function updatingSearch()
    {
        $this->resetPage();
    }
    public function render()
    {
        return view('livewire.components.public-flights', [
            'packages' => Package::whereLike([
                'category.name',
                'name',
                'description',
                'district.name'
            ], $this->search ?? '')->where('category_id', '2')->paginate(6),
        ]);
    }
}
