<?php

namespace App\Http\Livewire\Components;

use App\Models\Listing;
use App\Models\Package;
use Livewire\Component;

class PublicSearch extends Component
{

    public
        $results = [],
        $data;
    protected $queryString = ['data'];

    public function query()
    {

        // if (!empty($this->location)) {
        //     $this->dropdown = true;
        // } else {
        //     $this->dropdown = false;
        // }
        $this->results = Package::whereLike([
            'category.name',
            'name',
            'description',
            'district.name'
        ], $this->data ?? '')->limit(5)->get();
        // dd($this->results);
    }

    public function render()
    {
        return view('livewire.components.public-search');
    }
}
