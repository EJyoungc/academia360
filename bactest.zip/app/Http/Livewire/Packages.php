<?php

namespace App\Http\Livewire;

use App\Models\Category;
use App\Models\District;
use App\Models\Image;
use App\Models\Listing;
use App\Models\Location;
use App\Models\Package;
use Illuminate\Support\Collection;
use Illuminate\Support\Facades\Storage;
use Jantinnerezo\LivewireAlert\LivewireAlert;
use Livewire\Component;
use Livewire\WithFileUploads;

class Packages extends Component
{
    use WithFileUploads;
    use LivewireAlert;
    public
        $packages = [],
        $categories = [],
        $districts = [],
        $Name,
        $location,
        $category,
        $package,
        $district,
        $description,
        $image,
        $search,
        $location_id,
        $did,
        $show_map = false,
        $modal = false,
        $modal2 = false;

    protected $listeners = [
        'delete'
    ];

    //views
    public function create()
    {
        $this->modal = true;
    }
    public function edit($did)
    {

        $packages =  Package::find($did);
        // $l =  Location::where('package_id', $packages->id)->first();
        $this->Name =  $packages->name;
        $this->did = $did;
        $this->category = $packages->category_id;
        // $this->location = $l->coordinates;
        // $this->location_id = $l->id;
        $this->description = $packages->description;
        $this->district = $packages->district_id;
        $this->modal2 = true;
    }

    public function  deleteit($data)
    {
        $this->package = $data;
        $this->alert('warning', 'Package will be deleted along with its listings.Are You Sure You Want to Delete ? ', [
            'position' => 'center',
            'toast' => false,
            'timer' => null,
            'popup' => true,
            'backdrop' => true,
            'text' => null,
            'showCancelButton' => true,
            'onConfirmed' => 'delete',
            'showConfirmButton' => true,
            'confirmButtonText' => 'Delete'
        ]);
    }

    //operations

    public function query()
    {
        $this->packages = Package::whereLike(['category.name', 'district.name', 'description', 'name'], $this->search ?? '')->get();
    }

    public function showmap()
    {
        $this->show_map = true;
    }



    public function delete()
    {




        // delete all listing
        $listing = Listing::where('package_id', $this->package)->get();

        foreach ($listing as $item) {
            // dd($item->image);
            if (!$item->image == null) {

                Storage::delete($item->image);
            }

            $l2 = Listing::find($item->id);
            $l2->delete();
        }

        //delete image

        $i = Image::where('package_id', $this->package)->first();

        if (Storage::disk('public')->exists($i->image)) {

            Storage::delete($i->image);
        }
        $i2 = Image::find($i->id);
        $i2->delete();
        $d = Package::find($this->package);
        $d->delete();

        $this->show();
        $this->resetExcept('packages', 'districts', 'categories');
        $this->alert('success', 'Succefully Deleted Packages and their listings');
    }

    public function cancel()
    {
        $this->resetExcept('packages', 'districts', 'categories');
    }

    public function store()
    {
        $this->validate([
            // "inputs.*.file" => 'required|mimes:png,jpg,jpeg',
            "image" => 'required|mimes:png,jpg,jpeg',
            'category' => 'required',
            'district' => 'required',
            'Name' => 'required',
            'description' => 'required'
        ]);

        $file = $this->image->store('images');

        $p = Package::create([
            'name' => $this->Name,
            'category_id' => $this->category,
            'district_id' => $this->district,
            'description' => $this->description,
        ]);
        $image = Image::create([
            'image' => $file,
            'package_id' => $p->id
        ]);

        // $location = Location::create([
        //     'package_id' => $p->id,
        //     'coordinates' => $this->location
        // ]);


        $this->show();
        $this->resetExcept('packages', 'districts', 'categories');
        $this->alert('success', 'Successully added!');
    }

    public function update()
    {

        if ($this->image == "") {
            $this->validate([
                // "image" => 'required|mimes:png,jpg,jpeg',
                'category' => 'required',
                'district' => 'required',
                'Name' => 'required',
                'description' => 'required'
            ]);
            $p = Package::find($this->did);
            $p->name =  $this->Name;
            $p->category_id = $this->category;
            $p->district_id = $this->district;
            // $l = Location::find($this->location_id);
            // $l->coordinates = $this->location;
            // $l->save();
            $p->description =  $this->description;
            $p->save();

            $this->alert('success', 'Successully updated!');
            $this->show();
            $this->resetExcept('packages', 'districts', 'categories');
        } else {
            $this->validate([
                "image" => 'required|mimes:png,jpg,jpeg',
                'category' => 'required',
                'district' => 'required',
                'Name' => 'required',
                'description' => 'required'
            ]);
            $p = Package::find($this->did);
            $p->name =  $this->Name;
            $p->category_id = $this->category;
            $p->district_id = $this->district;
            $i = Image::where('package_id', $p->id)->first();
            Storage::delete($i->image);
            $file =  $this->image->store('images');
            $i2 = Image::find($i->id);
            $i2->image = $file;
            $i2->save();
            // $l = Location::find($this->location_id);
            // $l->coordinates = $this->location;
            // $l->save();
            $p->description =  $this->description;
            $p->save();

            $this->show();
            $this->alert('success', 'Successully updated!');
            $this->resetExcept('packages', 'districts', 'categories');
        }
    }
    public function show()
    {
        $this->packages = Package::all();
        $this->categories = Category::all();
        $this->districts = District::all();
    }
    public function mount()
    {
        $this->fill([
            'inputs' => collect([['email' => '']]),
        ]);
        $this->show();
    }
    public function render()
    {
        return view('livewire.packages', [
            'packages' => $this->packages,
            'categories' => $this->categories,
            'districts' => $this->districts,
        ]);
    }
}
