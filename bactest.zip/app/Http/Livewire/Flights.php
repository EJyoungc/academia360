<?php

namespace App\Http\Livewire;

use App\Models\Country;
use App\Models\District;
use App\Models\Listing;
use App\Models\Package;
use Illuminate\Support\Facades\Storage;
use Jantinnerezo\LivewireAlert\LivewireAlert;
use Livewire\Component;
use Livewire\WithFileUploads;

class Flights extends Component
{

    use LivewireAlert;
    use WithFileUploads;
    public
        $flights = [],
        $categories = [],
        $package,
        $districts = [],
        $description,
        $international,
        $packages = [],
        $price,
        $type,
        $departure,
        $arrival,
        $to,
        $from,
        $image,
        $flight,
        $search,
        $show_map = false,
        $modal = false,
        $modal2 = false;

    protected $listeners = [
        'delete'
    ];

    public function changetype()
    {
        if ($this->international == true) {
            $this->districts = Country::all();
        } else {
            $this->districts = District::all();
        }
    }

    public function  deleteit($data)
    {
        $this->flight = $data;
        $this->alert('warning', 'Are You Sure You Want to Delete ? ', [
            'position' => 'center',
            'toast' => false,
            'timer' => null,
            'popup' => true,
            'backdrop' => true,
            'text' => null,
            'showCancelButton' => true,
            'onConfirmed' => 'delete',
            'showConfirmButton' => true,
            'confirmButtonText' => 'Delete'
        ]);
    }

    public function query()
    {
        $this->flights =
            Listing::join('packages', 'package_id', 'packages.id')
            ->join('categories', 'category_id', '=', 'categories.id')
            ->where('categories.id', '=', '2')
            ->whereLike(['flight_from', 'flight_to', 'price', 'package.name',], $this->search ?? '')
            ->select('listings.*')
            ->get();
        // $this->flights = Listing::whereLike(['id', 'district.name', 'flight_type', 'price', 'description', 'package.name',], $this->search ?? '')->get();
    }
    public function create()
    {

        $this->modal = true;
    }
    public function cancel()
    {

        $this->resetExcept('flights', 'packages', 'district');
    }

    public function delete()
    {
        $r = Listing::find($this->flight);
        $r->delete();
        $this->show();
        $this->resetExcept('flights', 'packages', 'district');
        $this->alert('success', 'Successfully deleted flight!');
    }

    public function edit($flight)
    {
        $r = Listing::find($flight);
        $this->flight = $flight;
        $this->departure = $r->flight_departure;
        $this->arrival = $r->flight_arrival;
        $this->to = $r->flight_to;
        $this->type = $r->flight_type;
        $this->from = $r->flight_from;
        $this->international = $r->flight_international;
        if ($this->international == 'true') {
            $this->districts = Country::all();
        } else {
            $this->districts = District::all();
        }
        $this->price = $r->price;
        $this->package = $r->package_id;
        $this->description = $r->description;
        $this->modal2 = true;
    }

    public function show()
    {
        $this->districts = District::all();
        $this->packages = Package::where('category_id', '2')->get();
        $this->flights =
            Listing::join('packages', 'package_id', 'packages.id')
            ->join('categories', 'category_id', '=', 'categories.id')
            ->where('categories.id', '=', '2')
            ->select('listings.*')
            ->get();
    }

    public function mount()
    {
        $this->show();
    }

    public function update()
    {

        $this->validate([
            'departure' => 'required|string',
            'type' => 'required|string',
            'arrival' => 'required|string',
            'to' => 'required|string',
            'from' => 'required|string',
            'price' => 'required|numeric',
            'package' => 'required',
            'description' => 'required',
        ]);

        $r = Listing::find($this->flight);

        $r->flight_departure = $this->departure;
        $r->flight_arrival = $this->arrival;
        $r->flight_type = $this->type;
        $r->flight_to = $this->to;
        $r->flight_from = $this->from;
        $r->flight_international = $this->international;

        $r->price = $this->price;
        $r->package_id = $this->package;
        $r->description = $this->description;
        $r->save();
        $this->show();
        $this->resetExcept('flights', 'packages', 'district');
        $this->alert('success', 'Successfully Update flight!');
    }


    public function store()
    {
        $this->validate([
            'type' => 'required|string',
            'departure' => 'required|string',
            'arrival' => 'required|string',
            'to' => 'required|string',
            'from' => 'required|string',
            'price' => 'required|numeric',
            'package' => 'required',
            'description' => 'required',


        ]);




        // $file = $this->image->store('images');

        $l = new Listing();
        $l->flight_departure = $this->departure;
        $l->flight_arrival = $this->arrival;
        $l->flight_type = $this->type;
        $l->flight_to = $this->to;
        $l->flight_from = $this->from;
        $l->flight_international = $this->international;


        $l->price = $this->price;
        $l->package_id = $this->package;
        $l->description = $this->description;
        $l->save();
        $this->show();
        $this->resetExcept('flights', 'packages', 'district');
        $this->alert('success', 'Successfully added flight!');
    }

    public function render()
    {
        return view('livewire.flights');
    }
}
