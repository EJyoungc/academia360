<?php

namespace App\Http\Livewire;

use App\Models\Listing;
use App\Models\Package;
use Illuminate\Support\Facades\Storage;
use Jantinnerezo\LivewireAlert\LivewireAlert;
use Livewire\Component;
use Livewire\WithFileUploads;


class Attractions extends Component
{
    use LivewireAlert;
    use WithFileUploads;
    public
        $attractions = [],
        $categories = [],
        $package,
        $description,
        $packages = [],
        $price,
        $image,
        $attraction,
        $search,
        $show_map = false,
        $modal = false,
        $modal2 = false;

    protected $listeners = [
        'delete'
    ];

    public function  deleteit($data)
    {
        $this->attraction = $data;
        $this->alert('warning', 'Are You Sure You Want to Delete ? ', [
            'position' => 'center',
            'toast' => false,
            'timer' => null,
            'popup' => true,
            'backdrop' => true,
            'text' => null,
            'showCancelButton' => true,
            'onConfirmed' => 'delete',
            'showConfirmButton' => true,
            'confirmButtonText' => 'Delete'
        ]);
    }

    public function query()
    {
        $this->attractions =
            Listing::join('packages', 'package_id', 'packages.id')
            ->join('categories', 'category_id', '=', 'categories.id')
            ->where('categories.id', '=', '3')
            ->whereLike(['price', 'package.name',], $this->search ?? '')
            ->select('listings.*')
            ->get();
        // $this->attraction = Listing::whereLike(['id', 'district.name', 'price', 'description', 'package.name',], $this->search ?? '')->get();
    }
    public function create()
    {

        $this->modal = true;
    }
    public function cancel()
    {

        $this->resetExcept(['attractions', 'packages']);
    }

    public function delete()
    {
        $l = Listing::find($this->attraction);
        Storage::delete($l->image);
        $l->delete();
        $this->show();
        $this->resetExcept('attractions', 'packages');
        $this->alert('success', 'Successfully deleted attractions!');
    }

    public function edit($attraction)
    {
        $l = Listing::find($attraction);
        $this->attraction = $attraction;
        $this->price = $l->price;
        $this->package = $l->package_id;
        $this->description = $l->description;
        $this->modal2 = true;
    }

    public function show()
    {

        $this->packages = Package::where('category_id', '3')->get();
        $this->attractions = Listing::join('packages', 'package_id', 'packages.id')
            ->join('categories', 'category_id', '=', 'categories.id')
            ->where('categories.id', '=', '3')
            ->select('listings.*')
            ->get();
    }

    public function mount()
    {
        $this->show();
    }

    public function update()
    {

        if ($this->image == "") {
            $this->validate([
                'price' => 'required|numeric',
                'package' => 'required',
                'description' => 'required',
                // 'image' => 'required|mimes:jpg,png,jpeg'

            ]);

            $l = Listing::find($this->attraction);
            $l->price = $this->price;
            $l->package_id = $this->package;
            $l->description = $this->description;
            $l->save();
            $this->show();
            $this->resetExcept('attractions', 'packages');
            $this->alert('success', 'Successfully Update Attraction!');
        } else {
            $this->validate([

                'price' => 'required|numeric',
                'package' => 'required',
                'description' => 'required',
                'image' => 'required|mimes:jpg,png,jpeg'

            ]);
            $l = Listing::find($this->attraction);
            Storage::delete($l->image);
            $file = $this->image->store('images');

            $l->price = $this->price;
            $l->package_id = $this->package;
            $l->description = $this->description;
            $l->image = $file;
            $l->save();
            $this->show();
            $this->resetExcept('attractions', 'packages');
            $this->alert('success', 'Successfully Update !');
        }
    }


    public function store()
    {
        $this->validate([
            'price' => 'required|numeric',
            'package' => 'required',
            'description' => 'required',
            'image' => 'required|mimes:jpg,png,jpeg'

        ]);




        $file = $this->image->store('images');

        $l = new Listing();
        $l->price = $this->price;
        $l->package_id = $this->package;
        $l->description = $this->description;
        $l->image = $file;
        $l->save();
        $this->show();
        $this->resetExcept(['attractions']);
        $this->alert('success', 'Successfully added !');
    }


    public function render()
    {
        return view('livewire.attractions', [
            'attractions' => $this->attractions,
            'categories' => $this->categories,
            'packages' => $this->packages,
        ]);
    }
}
