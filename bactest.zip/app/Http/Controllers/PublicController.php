<?php

namespace App\Http\Controllers;

use App\Models\Category;
use App\Models\Listing;
use App\Models\Package;
use Illuminate\Http\Request;

class PublicController extends Controller
{
    //

    public function index()
    {
        return view('welcome')->with('packages', Package::inRandomOrder()->limit(6)->get())->with('categories', Category::all());

        //
    }

    public function services()
    {
        return view('livewire.public.services.index');
    }


    public function about()
    {

        return view('livewire.public.about.index');
    }
    public function stays()
    {
        return view('livewire.public.stays.index');
    }

    public function carrentals()
    {
        return view('livewire.public.carrentals.index');
    }

    public function taxi()
    {
        return view('livewire.public.taxi.index');
    }
    public function attractions()
    {
        return view('livewire.public.attractions.index');
    }

    public function flights()
    {
        return view('livewire.public.flights.index');
    }
}
