<?php

namespace App\Http\Controllers;

use App\Http\Controllers;
use App\Http\Controllers\DashboardController;
use App\Http\Livewire\Attractions;
use App\Http\Livewire\Booking;
use App\Http\Livewire\Carrentals;
use App\Http\Livewire\Categories;
use App\Http\Livewire\Flights;
use App\Http\Livewire\Locations;
use App\Http\Livewire\Packages;
use App\Http\Livewire\Payments;
use App\Http\Livewire\Public\Attractions\Showattractions;
use App\Http\Livewire\Public\Booking\Book;
use App\Http\Livewire\Public\Carrentals\Showcarrentals;
use App\Http\Livewire\Public\Flights\Showflights;
use App\Http\Livewire\Public\Stays\Showstays;
use App\Http\Livewire\Public\Taxi\Showtaxi;
use App\Http\Livewire\Rooms;
use App\Http\Livewire\Stays;
use App\Http\Livewire\Taxis;
use App\Http\Livewire\Users;
use App\Http\Middleware\VerifyMobile;
use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

//public

Route::get('/', [PublicController::class, 'index'])->name('root.index');
Route::get('/about', [PublicController::class, 'about'])->name('root.about');
Route::get('/services', [PublicController::class, 'services'])->name('root.services');
Route::get('/carrentals', [PublicController::class, 'carrentals'])->name('root.carrentals');
Route::get('/flights', [PublicController::class, 'flights'])->name('root.fights');
Route::get('/attractions', [PublicController::class, 'attractions'])->name('root.attractions');
Route::get('/airporttaxi', [PublicController::class, 'taxi'])->name('root.airports');
Route::get('/stays', [PublicController::class, 'stays'])->name('root.stays');
// Route::get('/airporttaxi/show/{id}', [PublicController::class, 'taxi'])->name('root.show.airports');


Route::get('/book/listings/{id}', Book::class)->name('root.book.listing');

//stays

Route::get('/stays/show/{id}', Showstays::class)->name('root.show.stays');
Route::get('/flights/show/{id}', Showflights::class)->name('root.show.flights');
Route::get('/airporttaxi/show/{id}', Showtaxi::class)->name('root.show.taxi');
Route::get('/attractions/show/{id}', Showattractions::class)->name('root.show.attractions');
Route::get('/carrentals/show/{id}', Showcarrentals::class)->name('root.show.carrent'); // Route::get('/', [PublicController::class, 'index'])->name('root.index');


//logged in

Route::middleware([
    'verifymobile',
    'auth:sanctum',
    config('jetstream.auth_session'),
    'verified',
])->group(function () {


    Route::get('/dashboard', [DashboardController::class,  'index'])->middleware('verifymobile')->name('dashboard');
    Route::get('dashboard/users', Users::class)->name('l.users');
    Route::get('dashboard/categories', Categories::class)->name('l.categories');
    Route::get('dashboard/packages', Packages::class)->name('l.packages');
    Route::get('dashboard/rooms', Rooms::class)->name('l.rooms');
    Route::get('dashboard/carrentals', Carrentals::class)->name('l.carrentals');
    Route::get('dashboard/attractions', Attractions::class)->name('l.attractions');
    Route::get('dashboard/taxis', Taxis::class)->name('l.taxis');
    Route::get('dashboard/flights', Flights::class)->name('l.flights');
    Route::get('dashboard/payments', Payments::class)->name('l.payments');
    Route::get('dashboard/booking', Booking::class)->name('l.booking');
});
