<?php

namespace Database\Seeders;

use App\Models\Category;
use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;

class CategorySeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        //
        Category::create([
            'name' => 'Hotels'
        ]);
        Category::create([
            'name' => 'Flights'
        ]);
        Category::create([
            'name' => 'Attractions'
        ]);
        Category::create([
            'name' => 'Taxis'
        ]);
        Category::create([
            'name' => 'Car Rental'
        ]);
    }
}
