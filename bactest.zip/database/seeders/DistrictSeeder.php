<?php

namespace Database\Seeders;

use App\Models\District;
use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;

class DistrictSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        //
        District::create([
            "name" => 'Dedza'
        ]);

        District::create([
            "name" => 'Dowa'
        ]);
        District::create([
            "name" => 'Lilongwe'
        ]);
        District::create([
            "name" => 'Mchinji'
        ]);
        District::create([
            "name" => 'Nkhotakota'
        ]);
        District::create([
            "name" => 'Ntcheu'
        ]);
        District::create([
            "name" => 'Ntchisi'
        ]);
        District::create([
            "name" => 'Salima'
        ]);
        District::create([
            "name" => 'Chitipa'
        ]);
        District::create([
            "name" => 'Karonga'
        ]);
        District::create([
            "name" => 'Likoma'
        ]);
        District::create([
            "name" => 'Mzimba'
        ]);
        District::create([
            "name" => 'Nkhata Bay'
        ]);
        District::create([
            "name" => 'Rumphi'
        ]);
        District::create([
            "name" => 'Balaka'
        ]);
        District::create([
            "name" => 'Blantyre'
        ]);
        District::create([
            "name" => 'Chikwawa'
        ]);
        District::create([
            "name" => 'Chiladzuru'
        ]);
        District::create([
            "name" => 'Machinga'
        ]);
        District::create([
            "name" => 'Mangochi'
        ]);
        District::create([
            "name" => 'Mulanje'
        ]);
        District::create([
            "name" => 'Mwanza'
        ]);
        District::create([
            "name" => 'Nsanje'
        ]);
        District::create([
            "name" => 'Thyolo'
        ]);
        District::create([
            "name" => 'Phalombe'
        ]);
        District::create([
            "name" => 'Zomba'
        ]);
        District::create([
            "name" => 'Neno'
        ]);
        District::create([
            "name" => 'Rumphi'
        ]);
    }
}
