<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('listings', function (Blueprint $table) {
            $table->id();
            $table->integer('package_id');
            $table->string('room_type')->nullable();
            $table->string('price')->nullable();
            $table->longText('description');
            $table->string('taxi_driver_name')->nullable();
            $table->string('taxi_driver_mobile')->nullable();
            $table->string('car_rental_type')->nullable();
            $table->string('flight_departure')->nullable();
            $table->string('flight_arrival')->nullable();
            $table->string('flight_type')->nullable();
            $table->string('flight_to')->nullable();
            $table->string('flight_from')->nullable();
            // $table->string('flight_international_to')->nullable();
            // $table->string('flight_international_from')->nullable();
            $table->string('flight_international')->nullable();

            $table->string('status')->default('available');
            $table->string('image')->nullable();

            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('listings');
    }
};
