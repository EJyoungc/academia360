<!-- ======= Footer ======= -->
<footer id="footer">

    

    <div class="footer-top">
        <div class="container">
            <div class="row">

                <div class="col-lg-4 col-md-6 footer-links">
                    <h4>Useful Links</h4>
                    <ul>
                        <li><i class="bx bx-chevron-right"></i> <a href="<?php echo e(route('root.index')); ?>">Home</a></li>
                        <li><i class="bx bx-chevron-right"></i> <a href="<?php echo e(route('root.about')); ?>">About us</a></li>
                        <li><i class="bx bx-chevron-right"></i> <a href="<?php echo e(route('root.services')); ?>">Services</a></li>
                        <li><i class="bx bx-chevron-right"></i> <a href="<?php echo e(route('login')); ?>">Login</a></li>
                        <li><i class="bx bx-chevron-right"></i> <a href="<?php echo e(route('register')); ?>">Register</a></li>
                    </ul>
                </div>

                <div class="col-lg-4 col-md-6 footer-links">
                    <h4>Our Services</h4>
                    <ul>
                        <li><i class="bx bx-chevron-right"></i> <a href="<?php echo e(route('root.stays')); ?>">Stays</a></li>
                        <li><i class="bx bx-chevron-right"></i> <a href="<?php echo e(route('root.fights')); ?>">Flights</a></li>
                        <li><i class="bx bx-chevron-right"></i> <a href="<?php echo e(route('root.carrentals')); ?>">Car rentals</a>
                        </li>
                        <li><i class="bx bx-chevron-right"></i> <a
                                href="<?php echo e(route('root.attractions')); ?>">Attractions</a></li>
                        <li><i class="bx bx-chevron-right"></i> <a href="<?php echo e(route('root.airports')); ?>">Taxi</a></li>
                    </ul>
                </div>

                <div class="col-lg-4 col-md-6 footer-contact">
                    <h4>Contact Us</h4>
                    <p>
                        BCA Travel Limited <br>
                        P.O BOX 1967 <br>
                        Office 6,2nd floor,
                        European Business Center,
                        Area 3, Lilongwe. <br>
                        <strong>Phone:</strong> +265 984 901 590<br>
                        <strong>Phone:</strong> +265 992 734 108<br>
                        <strong>Email:</strong> info@abcatravel.com<br>
                        <strong>Email:</strong> bcatravelmalawi@gmail.com<br>
                    </p>

                </div>



            </div>
        </div>
    </div>

    <div class="container">
        <div class="copyright">
            &copy; Copyright <strong><span>BCA Travels</span></strong>. All Rights Reserved
        </div>
        <div class="credits">
            Designed by <a href="#">CoolEnterprises Malawi</a>
        </div>
    </div>
</footer><!-- End Footer -->
<?php /**PATH C:\laragon\www\hello\resources\views/aside/footer.blade.php ENDPATH**/ ?>