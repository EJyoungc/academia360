<button <?php echo e($attributes->merge(['type' => 'submit', 'class' => 'btn btn-dark text-uppercase'])); ?>>
    <?php echo e($slot); ?>

</button>
<?php /**PATH C:\laragon\www\hello\resources\views/vendor/jetstream/components/button.blade.php ENDPATH**/ ?>