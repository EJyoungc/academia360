<?php $__env->startSection('content'); ?>
    <div>
        

        <section id="hero" class="d-flex justify-cntent-center align-items-center">
            <div id="heroCarousel" data-bs-interval="5000" class="container carousel carousel-fade" data-bs-ride="carousel">

                <!-- Slide 1 -->
                <div class="carousel-item active">
                    <div class="carousel-container">
                        <h2 class="animate__animated animate__fadeInDown">Welcome </h2>
                        <p class="animate__animated animate__fadeInUp">Get the best deals in the country.</p>
                        
                    </div>
                </div>

                <!-- Slide 2 -->
                <div class="carousel-item">
                    <div class="carousel-container">
                        <h2 class="animate__animated animate__fadeInDown">Find Your stay</h2>
                        
                        
                    </div>
                </div>




                <a class="carousel-control-prev" href="#heroCarousel" role="button" data-bs-slide="prev">
                    <span class="carousel-control-prev-icon bx bx-chevron-left" aria-hidden="true"></span>
                </a>

                <a class="carousel-control-next" href="#heroCarousel" role="button" data-bs-slide="next">
                    <span class="carousel-control-next-icon bx bx-chevron-right" aria-hidden="true"></span>
                </a>

            </div>
        </section><!-- End Hero -->

        <main id="main" class="grad-back">

            <!-- ======= Icon Boxes Section ======= -->
            <section id="icon-boxes" class="icon-boxes">
                <div class="container">

                    <div class="row">
                        <div class="col-md-12 col-lg-12  align-items-stretch mb-lg-0" data-aos="fade-up">
                            <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('components.public-search')->html();
} elseif ($_instance->childHasBeenRendered('2JvPkxL')) {
    $componentId = $_instance->getRenderedChildComponentId('2JvPkxL');
    $componentTag = $_instance->getRenderedChildComponentTagName('2JvPkxL');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('2JvPkxL');
} else {
    $response = \Livewire\Livewire::mount('components.public-search');
    $html = $response->html();
    $_instance->logRenderedChild('2JvPkxL', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
                        </div>
                    </div>

                </div>
            </section><!-- End Icon Boxes Section -->


            <section id="portfolio" class="portfoio">
                <div class="container" data-aos="fade-up">

                    <div class="section-title">
                        <h2 class="text-light">Places of Interest</h2>

                    </div>

                    <div class="row">
                        <div class="col-lg-12 d-flex justify-content-center">
                            <ul id="portfolio-flters">
                                <li data-filter="*" class="text-white" class="filter-active">All</li>
                                <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <li class="text-white border-light" data-filter=".<?php echo e(Str::slug($item->name)); ?>">
                                        <?php echo e($item->name); ?></li>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                            </ul>
                        </div>
                    </div>



                    <div class="row  portfoio  portfolio-container ">
                        <?php $__empty_1 = true; $__currentLoopData = $packages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            <div class="col-lg-4 col-md-6 portfolio-item <?php echo e(Str::slug($item->category->name)); ?>">
                                <img src="<?php echo e(url('storage/' . $item->image->image)); ?>" class="img-style imgclass"
                                    alt="">
                                <div class="portfolio-info text-center">
                                    <h4><?php echo e($item->name); ?></h4>

                                    <p><?php echo e($item->category->name); ?></p>
                                    <p><?php echo e($item->listings->count()); ?> Listings</p>

                                    <a href="<?php echo e(url('storage/' . $item->image)); ?>" data-gallery="portfolioGallery"
                                        class="portfolio-lightbox preview-link" title="Book"><i
                                            class="bx bx-plus"></i></a>
                                    <a href="<?php if($item->category->id == '1'): ?> <?php echo e(route('root.show.stays', $item->id)); ?>

                                            <?php elseif($item->category->id == '2'): ?>
                                            <?php echo e(route('root.show.flights', $item->id)); ?>

                                            <?php elseif($item->category->id == '3'): ?>
                                            <?php echo e(route('root.show.attractions', $item->id)); ?>

                                            <?php elseif($item->category->id == '4'): ?>
                                            <?php echo e(route('root.show.taxi', $item->id)); ?>

                                            <?php else: ?>
                                            <?php echo e(route('root.show.carrent', $item->id)); ?> <?php endif; ?>"
                                        class="btn btn-outline-light" title="More Details">
                                        Book now
                                    </a>
                                </div>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <?php endif; ?>
                    </div>

                </div>
            </section><!-- End Portfoio Section -->




        </main><!-- End #main -->
    <?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.root2', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\hello\resources\views/welcome.blade.php ENDPATH**/ ?>