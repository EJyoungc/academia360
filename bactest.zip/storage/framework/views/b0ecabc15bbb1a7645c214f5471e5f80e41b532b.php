<div>
    

    <div class="mt-5">
        <div class="row justify-content-center">
            <div class="col-md-8">
                <div class="input-group rounded-pill mb-3 shadow-sm p-3 bg-body rounded">
                    <span class="input-group-text text-muted bg-white border-0"> <i class="ri-search-line"></i></span>
                    <input type="search" wire:model="data" wire:keydown='query'
                        class="form-control border-0  rounded-5 me-4 " placeholder="Search...">
                </div>
            </div>
        </div>
        <?php if(!empty($data)): ?>
            <div class="row justify-content-center pt-3">
                <div class="col-md-8">

                    <div class="list-group">
                        <?php $__empty_1 = true; $__currentLoopData = $results; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            <a href="
                            <?php if($item->category->id == '1'): ?> <?php echo e(route('root.show.stays', $item->id)); ?>

                            <?php elseif($item->category->id == '2'): ?>
                             <?php echo e(route('root.show.flights', $item->id)); ?>


                            <?php elseif($item->category->id == '3'): ?>
                             <?php echo e(route('root.show.attractions', $item->id)); ?>


                            <?php elseif($item->category->id == '4'): ?>
                             <?php echo e(route('root.show.taxi', $item->id)); ?>


                            <?php else: ?>
                             <?php echo e(route('root.show.carrent', $item->id)); ?> <?php endif; ?>
                            "
                                class="list-group-item list-group-item-action">
                                <div class="d-flex">
                                    <img src="<?php echo e(url('storage/' . $item->image->image)); ?>" width="80" height="80"
                                        alt="" srcset="">
                                    <div class=" flex-column w-100 ps-2 align-items-start ">
                                        <div class="d-flex  justify-content-between">
                                            <h5 class="mb-1 pe-1 pt-1"><?php echo e($item->name); ?></h5>
                                            <small><?php echo e($item->district->name); ?></small>
                                        </div>
                                        <p class="mb-1"><?php echo e($item->category->name); ?></p>
                                        <small> <span class="text-primary">
                                                <?php echo e($item->listings->count()); ?> Listing Available</span></small>
                                    </div>
                                </div>

                            </a>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                            <a href="#" class="list-group-item list-group-item-action">
                                <div class="text-center text-muted">EMPTY</div>
                            </a>
                        <?php endif; ?>

                    </div>
                </div>
            </div>
        <?php endif; ?>

    </div>
</div>
<?php /**PATH C:\laragon\www\hello\resources\views/livewire/components/public-search.blade.php ENDPATH**/ ?>