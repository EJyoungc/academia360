    <!-- ======= Top Bar ======= -->
    <div id="topbar"
        class="fixed-top d-flex align-items-center page-container <?php if(request()->routeIs('root.services') || request()->routeIs('root.about')): ?> topbar-inner-pages <?php else: ?> topbar-inner-pages <?php endif; ?> ">
        <div class="container d-flex align-items-center justify-content-center justify-content-md-between">
            <div class="contact-info d-flex align-items-center">
                <i class="bi bi-envelope-fill"></i><a href="mailto:info@abcatravel.com">info@abcatravel.com</a>
                <i class="bi bi-phone-fill phone-icon"></i> +265 992 734 108
            </div>
            <div class="d-none d-md-block">
                <?php if(Route::has('login')): ?>
                    <div class="">
                        <?php if(auth()->guard()->check()): ?>
                            <a href="<?php echo e(url('/dashboard')); ?>" class="btn btn-outline-light">Dashboard</a>
                        <?php else: ?>
                            <a href="<?php echo e(route('login')); ?>" class="btn btn-outline-light">Log in</a>

                            <?php if(Route::has('register')): ?>
                                <a href="<?php echo e(route('register')); ?>" class="ms-4 btn btn-outline-light">Register</a>
                            <?php endif; ?>
                    <?php endif; ?>
                </div>
                <?php endif; ?>
            </div>
        </div>
        </div>

        <!-- ======= Header ======= -->
        <header id="header" class="fixed-top d-flex align-items-center  header-inner-pages page-container ">
            <div class="container d-flex align-items-center justify-content-between">

                <h1 class="logo"><a href="<?php echo e(route('root.index')); ?>">BCA Travels</a></h1>
                <!-- Uncomment below if you prefer to use an image logo -->
                <!-- <a href=index.html" class="logo"><img src="assets/img/logo.png" alt="" class="img-fluid"></a>-->
                <nav id="navbar" class="navbar">
                    <ul>
                        <li><a class="nav-link " href="<?php echo e(route('root.stays')); ?>">Stays</a></li>
                        <li><a class="nav-link " href="<?php echo e(route('root.fights')); ?>">Flights</a></li>
                        <li><a class="nav-link " href="<?php echo e(route('root.carrentals')); ?>">Car rentals</a></li>
                        <li><a class="nav-link " href="<?php echo e(route('root.attractions')); ?>">Attractions</a></li>
                        <li><a class="nav-link " href="<?php echo e(route('root.airports')); ?>">Airport Traxis</a></li>
                        <li><a class="nav-link " href="<?php echo e(route('root.services')); ?>">Services</a></li>
                        <li><a class="nav-link " href="<?php echo e(route('root.about')); ?>">About Us</a></li>
                        <?php if(Route::has('login')): ?>

                            <?php if(auth()->guard()->check()): ?>
                                <li><a class="nav-link d-lg-none " href="<?php echo e(route('dashboard')); ?>">Dashboard</a></li>
                            <?php else: ?>
                                <li><a class="nav-link d-lg-none " href="<?php echo e(route('login')); ?>">Sign-In</a></li>
                                <?php if(Route::has('register')): ?>
                                    <li><a class="nav-link d-lg-none " href="<?php echo e(route('register')); ?>">Register</a></li>
                                <?php endif; ?>

                            <?php endif; ?>

                            <?php endif; ?>



                            <!-- <li><a href="blog.html">Blog</a></li> -->
                            <!-- <li class="dropdown"><a href="#"><span>Drop Down</span> <i class="bi bi-chevron-down"></i></a>
                                                                                                <ul>
                                                                                                    <li><a href="#">Drop Down 1</a></li>
                                                                                                    <li class="dropdown"><a href="#"><span>Deep Drop Down</span> <i
                                                                                                                class="bi bi-chevron-right"></i></a>
                                                                                                        <ul>
                                                                                                            <li><a href="#">Deep Drop Down 1</a></li>
                                                                                                            <li><a href="#">Deep Drop Down 2</a></li>
                                                                                                            <li><a href="#">Deep Drop Down 3</a></li>
                                                                                                            <li><a href="#">Deep Drop Down 4</a></li>
                                                                                                            <li><a href="#">Deep Drop Down 5</a></li>
                                                                                                        </ul>
                                                                                                    </li>
                                                                                                    <li><a href="#">Drop Down 2</a></li>
                                                                                                    <li><a href="#">Drop Down 3</a></li>
                                                                                                    <li><a href="#">Drop Down 4</a></li>
                                                                                                </ul>
                                                                                            </li> -->
                            <!-- <li><a class="nav-link scrollto" href="#contact">Contact</a></li> -->
                        </ul>
                        <i class="bi bi-list mobile-nav-toggle"></i>
                    </nav><!-- .navbar -->

                </div>
            </header><!-- End Header -->
<?php /**PATH C:\laragon\www\hello\resources\views/aside/nav2.blade.php ENDPATH**/ ?>