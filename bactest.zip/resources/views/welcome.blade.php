@extends('layouts.root2')


@section('content')
    <div>
        {{-- The Master doesn't talk, he acts. --}}

        <section id="hero" class="d-flex justify-cntent-center align-items-center">
            <div id="heroCarousel" data-bs-interval="5000" class="container carousel carousel-fade" data-bs-ride="carousel">

                <!-- Slide 1 -->
                <div class="carousel-item active">
                    <div class="carousel-container">
                        <h2 class="animate__animated animate__fadeInDown">Welcome </h2>
                        <p class="animate__animated animate__fadeInUp">Get the best deals in the country.</p>
                        {{-- <a href="#about" class="btn-get-started animate__animated animate__fadeInUp scrollto">Read More</a> --}}
                    </div>
                </div>

                <!-- Slide 2 -->
                <div class="carousel-item">
                    <div class="carousel-container">
                        <h2 class="animate__animated animate__fadeInDown">Find Your stay</h2>
                        {{-- <p class="animate__animated animate__fadeInUp">Ut velit est quam dolor ad a aliquid qui aliquid.
                            Sequi ea ut et est quaerat sequi nihil ut aliquam. Occaecati alias dolorem mollitia ut.
                            Similique ea voluptatem. Esse doloremque accusamus repellendus deleniti vel. Minus et tempore
                            modi architecto.</p> --}}
                        {{-- <a href="#about" class="btn-get-started animate__animated animate__fadeInUp scrollto">Read More</a> --}}
                    </div>
                </div>




                <a class="carousel-control-prev" href="#heroCarousel" role="button" data-bs-slide="prev">
                    <span class="carousel-control-prev-icon bx bx-chevron-left" aria-hidden="true"></span>
                </a>

                <a class="carousel-control-next" href="#heroCarousel" role="button" data-bs-slide="next">
                    <span class="carousel-control-next-icon bx bx-chevron-right" aria-hidden="true"></span>
                </a>

            </div>
        </section><!-- End Hero -->

        <main id="main" class="grad-back">

            <!-- ======= Icon Boxes Section ======= -->
            <section id="icon-boxes" class="icon-boxes">
                <div class="container">

                    <div class="row">
                        <div class="col-md-12 col-lg-12  align-items-stretch mb-lg-0" data-aos="fade-up">
                            @livewire('components.public-search')
                        </div>
                    </div>

                </div>
            </section><!-- End Icon Boxes Section -->


            <section id="portfolio" class="portfoio">
                <div class="container" data-aos="fade-up">

                    <div class="section-title">
                        <h2 class="text-light">Places of Interest</h2>

                    </div>

                    <div class="row">
                        <div class="col-lg-12 d-flex justify-content-center">
                            <ul id="portfolio-flters">
                                <li data-filter="*" class="text-white" class="filter-active">All</li>
                                @foreach ($categories as $item)
                                    <li class="text-white border-light" data-filter=".{{ Str::slug($item->name) }}">
                                        {{ $item->name }}</li>
                                @endforeach

                            </ul>
                        </div>
                    </div>



                    <div class="row  portfoio  portfolio-container ">
                        @forelse ($packages as $item)
                            <div class="col-lg-4 col-md-6 portfolio-item {{ Str::slug($item->category->name) }}">
                                <img src="{{ url('storage/' . $item->image->image) }}" class="img-style imgclass"
                                    alt="">
                                <div class="portfolio-info text-center">
                                    <h4>{{ $item->name }}</h4>

                                    <p>{{ $item->category->name }}</p>
                                    <p>{{ $item->listings->count() }} Listings</p>

                                    <a href="{{ url('storage/' . $item->image) }}" data-gallery="portfolioGallery"
                                        class="portfolio-lightbox preview-link" title="Book"><i
                                            class="bx bx-plus"></i></a>
                                    <a href="@if ($item->category->id == '1') {{ route('root.show.stays', $item->id) }}
                                            @elseif ($item->category->id == '2')
                                            {{ route('root.show.flights', $item->id) }}
                                            @elseif ($item->category->id == '3')
                                            {{ route('root.show.attractions', $item->id) }}
                                            @elseif ($item->category->id == '4')
                                            {{ route('root.show.taxi', $item->id) }}
                                            @else
                                            {{ route('root.show.carrent', $item->id) }} @endif"
                                        class="btn btn-outline-light" title="More Details">
                                        Book now
                                    </a>
                                </div>
                            </div>
                        @empty
                        @endforelse
                    </div>

                </div>
            </section><!-- End Portfoio Section -->




        </main><!-- End #main -->
    @endsection
