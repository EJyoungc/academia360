<x-app-layout>
    <div class="d-flex justify-content-between align-items-center flex-wrap grid-margin pb-3">
        <div>
            <h4 class="mb-3 mb-md-0">Dashboard</h4>
        </div>
        <div class="d-flex align-items-center flex-wrap text-nowrap">
            {{-- <button wire:click="create" class="btn btn-outline-secondary"> add</button> --}}


        </div>
    </div>

    <div class="row">
        <div class="col-md-3  pt-2">
            <div class="card">
                <div class="card-body rounded-1 bg-danger text-light">
                    <div class="h3">Booked</div>
                    <span>54</span>
                </div>
            </div>
        </div>
        <div class="col-md-3 pt-2">
            <div class="card shadow">
                <div class="card-body rounded-1 bg-primary text-light">
                    <div class="h3">Litsing</div>
                    <span>54</span>
                </div>
            </div>
        </div>
        <div class="col-md-3  pt-2">
            <div class="card">
                <div class="card-body rounded-1 bg-success text-light">
                    <div class="h3">Packages</div>
                    <span>0</span>
                </div>
            </div>
        </div>
        <div class="col-md-3  pt-2">
            <div class="card ">
                <div class="card-body rounded-1 bg-dark text-light ">
                    <div class="h3">Payments</div>
                    <span>54</span>
                </div>
            </div>
        </div>
    </div>

    <div class="row pt-3">
        <div class="col-sm-12">
            <div class="card">
                <div class="card-body">
                    <div class="h4">Booking Log</div>
                    <table class="table table-inverse table-inverse table-responsive">
                        <thead class="thead-inverse">
                            <tr class="table-light">
                                <th>#</th>
                                <th>Package</th>
                                <th>type</th>
                                <th>Listing</th>
                                <th>Status</th>
                            </tr>
                        </thead>
                        <tbody>
                            <tr>
                                <td scope="row"></td>
                                <td></td>
                                <td></td>
                                <td></td>
                                <td></td>

                            </tr>
                            <tr>
                                <td scope="row"></td>
                                <td></td>
                                <td></td>
                                <td></td>
                                <td></td>

                            </tr>
                            <tr>
                                <td scope="row"></td>
                                <td></td>
                                <td></td>
                                <td></td>
                                <td></td>

                            </tr>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</x-app-layout>
