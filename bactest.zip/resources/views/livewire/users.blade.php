<div>
    {{-- A good traveler has no fixed plans and is not intent upon arriving. --}}
    <div>
        {{-- Be like water. --}}

        <div>
            {{-- Knowing others is intelligence; knowing yourself is true wisdom. --}}
            <div class="d-flex justify-content-between align-items-center flex-wrap grid-margin pb-3">
                <div>
                    <h4 class="mb-3 mb-md-0">Users</h4>
                </div>
                <div class="d-flex align-items-center flex-wrap text-nowrap">
                    <button wire:click="create" class="btn btn-outline-secondary"> add</button>

                    <div class="modal  fade show " @if ($modal) style="display:block;" @endif
                        id="exampleModal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
                        <div class="modal-dialog ">
                            <div class="modal-content">
                                <div class="modal-header">
                                    <h5 class="modal-title" id="exampleModalLabel"></h5>
                                    <button wire:click="$set('modal', false)" type="button" class="btn-close"
                                        data-bs-dismiss="modal" aria-label="Close">
                                    </button>
                                </div>
                                <div class="modal-body">
                                    <div class="container">
                                        <div class="row">
                                            <div class="col-md-12">
                                                <div class="h3 text-center">Add User</div>

                                                <div class="form-group">
                                                    <label for="">name</label>
                                                    <input type="text"
                                                        class="form-control @error('name') is-invalid @enderror "
                                                        wire:model="name">
                                                    @error('name')
                                                        <span class="text-danger">
                                                            {{ $message }}
                                                        </span>
                                                    @enderror

                                                </div>

                                                <div class="form-group">
                                                    <label for="">Email</label>
                                                    <input type="email" wire:model="email"
                                                        class="form-control  @error('image') is-invalid @enderror">
                                                    @error('email')
                                                        <span class="text-danger">
                                                            {{ $message }}
                                                        </span>
                                                    @enderror
                                                </div>

                                                <div class="form-group">
                                                    <label for="">Role</label>
                                                    <select type="text"
                                                        class="form-control @error('role') is-invalid @enderror "
                                                        wire:model="role">
                                                        <option value="">Select</option>

                                                        <option value="admin">
                                                            Admin
                                                        </option>
                                                        <option value="regular">
                                                            Regular
                                                        </option>


                                                    </select>
                                                    @error('role')
                                                        <span class="text-danger">
                                                            {{ $message }}
                                                        </span>
                                                    @enderror

                                                </div>

                                                <div class="form-group">
                                                    <label for="">mobile</label>
                                                    <input type="text"
                                                        class="form-control @error('mobile') is-invalid @enderror "
                                                        wire:model="mobile">
                                                    @error('mobile')
                                                        <span class="text-danger">
                                                            {{ $message }}
                                                        </span>
                                                    @enderror

                                                </div>

                                                <div class="form-group">
                                                    <label for="">Password</label>
                                                    <input type="text"
                                                        class="form-control @error('password') is-invalid @enderror "
                                                        wire:model="password">
                                                    @error('password')
                                                        <span class="text-danger">
                                                            {{ $message }}
                                                        </span>
                                                    @enderror

                                                </div>

                                                <div class="form-group pt-1">
                                                    <button wire:click="store" class="btn btn-dark form-control">
                                                        Save
                                                    </button>
                                                </div>
                                            </div>


                                        </div>
                                    </div>

                                </div>

                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <div class="card rounded-5 shadow bg-light ">
                <div class="card-body rounded-5 bg-white">
                    <div class="col-md-12">
                        <div class="input-group rounded-pill  shadow  bg-body rounded">

                            <input type="text" wire:model="search" wire:keydown='query'
                                class="form-control border-0  rounded-5  " placeholder="Search...">
                        </div>

                    </div>
                    <div class="row pt-3">
                        <div class="col-md-12">
                            <table class="table table-hover table-inverse table-responsive">
                                <thead class="thead-inverse">
                                    <tr>
                                        <th>#</th>
                                        <th>name</th>
                                        <th>role</th>
                                        <th>Mobile</th>
                                        <th>Action</th>
                                    </tr>

                                <tbody>
                                    @forelse ($users as $item)
                                        <tr>
                                            <td scope="row">{{ $item->id }}</td>
                                            <td scope="row">{{ $item->name }}</td>
                                            <td>{{ $item->role }}</td>
                                            <td>{{ $item->mobile }}</td>
                                            <td>

                                                <button type="button" class="btn btn-primary dropdown-toggle"
                                                    data-bs-toggle="dropdown" aria-expanded="false">
                                                    Options
                                                </button>
                                                <ul class="dropdown-menu">
                                                    <li><a wire:click="edit({{ $item->id }})" class="dropdown-item"
                                                            href="#">Edit</a></li>
                                                    <li><a wire:click="deleteit({{ $item->id }})"
                                                            class="dropdown-item" href="#">Delete</a></li>
                                                </ul>
                                            </td>
                                        </tr>
                                    @empty
                                        <tr>
                                            <td colspan="6">
                                                <div class="text-center text-muted h4">EMPTY</div>
                                            </td>

                                        </tr>
                                    @endforelse


                                </tbody>
                            </table>
                            <!-- Token Value Modal -->
                            <div class="modal fade show "
                                @if ($modal2) style="display:block;" @endif id="exampleModal"
                                tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
                                <div class="modal-dialog">
                                    <div class="modal-content">
                                        <div class="modal-header">
                                            <h5 class="modal-title" id="exampleModalLabel"></h5>
                                            <button wire:click="cancel" type="button" class="btn-close"
                                                data-bs-dismiss="modal" aria-label="Close">
                                            </button>
                                        </div>
                                        <div class="modal-body">
                                            <div class="container">
                                                <div class="row">
                                                    <div class="col-md-12">
                                                        <div class="h3 text-center">Edit User</div>

                                                        <div class="form-group">
                                                            <label for="">name</label>
                                                            <input type="text"
                                                                class="form-control @error('name') is-invalid @enderror "
                                                                wire:model="name">
                                                            @error('name')
                                                                <span class="text-danger">
                                                                    {{ $message }}
                                                                </span>
                                                            @enderror

                                                        </div>

                                                        <div class="form-group">
                                                            <label for="">Email</label>
                                                            <input type="email" wire:model="email"
                                                                class="form-control  @error('image') is-invalid @enderror">
                                                            @error('email')
                                                                <span class="text-danger">
                                                                    {{ $message }}
                                                                </span>
                                                            @enderror
                                                        </div>

                                                        <div class="form-group">
                                                            <label for="">Role</label>
                                                            <select type="text"
                                                                class="form-control @error('role') is-invalid @enderror "
                                                                wire:model="role">
                                                                <option value="">Select</option>

                                                                <option value="admin">
                                                                    Admin
                                                                </option>
                                                                <option value="regular">
                                                                    Regular
                                                                </option>


                                                            </select>
                                                            @error('role')
                                                                <span class="text-danger">
                                                                    {{ $message }}
                                                                </span>
                                                            @enderror

                                                        </div>

                                                        <div class="form-group">
                                                            <label for="">mobile</label>
                                                            <input type="text"
                                                                class="form-control @error('mobile') is-invalid @enderror "
                                                                wire:model="mobile">
                                                            @error('mobile')
                                                                <span class="text-danger">
                                                                    {{ $message }}
                                                                </span>
                                                            @enderror

                                                        </div>
                                                        <div class="form-group">
                                                            <label for="">Password</label>
                                                            <input type="text"
                                                                class="form-control @error('password') is-invalid @enderror "
                                                                wire:model="password">
                                                            @error('password')
                                                                <span class="text-danger">
                                                                    {{ $message }}
                                                                </span>
                                                            @enderror

                                                        </div>

                                                        <div class="form-group pt-1">
                                                            <button wire:click="update"
                                                                class="btn btn-dark form-control">
                                                                Save
                                                            </button>
                                                        </div>
                                                    </div>


                                                </div>
                                            </div>

                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
