<div>
    {{-- Knowing others is intelligence; knowing yourself is true wisdom. --}}

    <div class="d-flex justify-content-between align-items-center flex-wrap grid-margin pb-3">
        <div>
            <h4 class="mb-3 mb-md-0">Categories</h4>
        </div>
        <div class="d-flex align-items-center flex-wrap text-nowrap">
            {{-- <button wire:click="createmodal" class="btn btn-outline-secondary"> add</button> --}}

            <div class="modal fade show " @if ($modal) style="display:block;" @endif
                id="exampleModal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
                <div class="modal-dialog">
                    <div class="modal-content">
                        <div class="modal-header">
                            <h5 class="modal-title" id="exampleModalLabel">Modal title</h5>
                            <button wire:click="$set('modal', false)" type="button" class="btn-close"
                                data-bs-dismiss="modal" aria-label="Close">
                            </button>
                        </div>
                        <div class="modal-body">
                            <div class="h3 text-center">Add Category</div>
                            <div class="form-group">
                                <label for="">Name</label>
                                <input type="text" class="form-control @error('Name') is-invalid @enderror "
                                    wire:model="Name">
                                @error('Name')
                                    <span class="text-danger">
                                        {{ $message }}
                                    </span>
                                @enderror

                            </div>
                            <div class="form-group pt-1">
                                <button wire:click="store" class="btn btn-dark form-control">
                                    Save
                                </button>
                            </div>

                        </div>

                    </div>
                </div>
            </div>


        </div>
    </div>
    <div class="row">
        

    </div>
    <div class="card rounded-5 shadow bg-light ">
        <div class="card-body rounded-5 bg-white">
            <div class="col-md-12">
                <div class="input-group rounded-pill  shadow-lg  bg-primary rounded">

                    <input type="text" wire:model.debounce.100ms="search" wire:keydown='query'
                        class="form-control border-0  rounded-5  " placeholder="Search...">
                </div>

            </div>
            <div class="row pt-3">
                <div class="col-md-12">
                    <table class="table table-hover table-inverse table-responsive">
                        <thead class="thead-inverse">
                            <tr>
                                <th>#</th>
                                <th>Category</th>

                                <th>action</th>
                            </tr>
                        </thead>
                        <tbody>
                            @forelse ($categories as $item)
                                <tr>
                                    <td scope="row">{{ $item->id }}</td>
                                    <td>{{ $item->name }}</td>

                                    <td>
                                        <button class="btn btn-info btn-sm"
                                            wire:click="edit({{ $item->id }})">Edit</button>
                                        {{-- <button class="btn btn-danger btn-sm"
                                            wire:click="deleteit({{ $item->id }})">Delete</button> --}}
                                    </td>
                                </tr>
                            @empty
                                <tr>
                                    <td colspan="3">
                                        <div class="text-center text-muted h4">EMPTY</div>
                                    </td>
                                </tr>
                            @endforelse


                        </tbody>
                    </table>
                    <!-- Token Value Modal -->
                    <div class="modal fade show " @if ($modal2) style="display:block;" @endif
                        id="exampleModal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
                        <div class="modal-dialog">
                            <div class="modal-content">
                                <div class="modal-header">
                                    <h5 class="modal-title" id="exampleModalLabel"></h5>
                                    <button wire:click="cancel" type="button" class="btn-close" data-bs-dismiss="modal"
                                        aria-label="Close">
                                    </button>
                                </div>
                                <div class="modal-body">
                                    <div class="h3 text-center">Edit Category</div>
                                    <div class="form-group">
                                        <label for="">Name</label>
                                        <input type="text" class="form-control @error('Name') is-invalid @enderror "
                                            wire:model="Name">
                                        @error('Name')
                                            <span class="text-danger">
                                                {{ $message }}
                                            </span>
                                        @enderror

                                    </div>
                                    <div class="form-group pt-1">
                                        <button wire:click="update" class="btn btn-dark form-control">
                                            Save
                                        </button>
                                    </div>

                                </div>

                            </div>
                        </div>
                    </div>

                </div>
            </div>
        </div>
    </div>


</div>
