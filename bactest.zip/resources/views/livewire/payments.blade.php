<div>
    {{-- A good traveler has no fixed plans and is not intent upon arriving. --}}

    {{-- Knowing others is intelligence; knowing yourself is true wisdom. --}}
    <div class="d-flex justify-content-between align-items-center flex-wrap grid-margin pb-3">
        <div>
            <h4 class="mb-3 mb-md-0">Payments</h4>
        </div>
        <div class="d-flex align-items-center flex-wrap text-nowrap">
            {{-- <button wire:click="create" class="btn btn-outline-secondary"> add</button> --}}


        </div>
    </div>

    <div class="card rounded-5 shadow bg-light ">
        <div class="card-body rounded-5 bg-white">
            <div class="col-md-12">
                <div class="input-group rounded-pill  shadow  bg-body rounded">

                    <input type="text" wire:model="search" wire:keydown='query'
                        class="form-control border-0  rounded-5  " placeholder="Search...">
                </div>

            </div>
            <div class="row pt-3">
                <div class="col-md-12">
                    <table class="table table-hover table-inverse table-responsive">
                        <thead class="thead-inverse">
                            <tr>
                                <th>#</th>
                                <th>User</th>
                                <th>Name</th>
                                <th>Package</th>
                                <th>Description</th>
                                <th>Price</th>
                                <th>status</th>
                                <th>Action</th>
                            </tr>

                        <tbody>
                            @forelse ($payments as $item)
                                <tr>
                                    <td scope="row">{{ $item->id }}</td>
                                    <td>
                                    </td>
                                    <td>{{ $item->room_type }}</td>
                                    <td>{{ $item->package->name }} {{ $item->package->district->name }} </td>

                                    <td>{{ $item->description }}</td>
                                    <td>MWK {{ $item->price }} .00</td>
                                    <td>

                                        <button type="button" class="btn btn-primary dropdown-toggle"
                                            data-bs-toggle="dropdown" aria-expanded="false">
                                            Options
                                        </button>
                                        <ul class="dropdown-menu">
                                            <li><a wire:click="edit({{ $item->id }})" class="dropdown-item"
                                                    href="#">Edit</a></li>
                                            <li><a wire:click="deleteit({{ $item->id }})" class="dropdown-item"
                                                    href="#">Delete</a></li>
                                        </ul>
                                    </td>
                                </tr>
                            @empty
                                <tr>
                                    <td colspan="6">
                                        <div class="text-center text-muted h4">EMPTY</div>
                                    </td>

                                </tr>
                            @endforelse


                        </tbody>
                    </table>

                </div>
            </div>
        </div>
    </div>
</div>
</div>
</div>
