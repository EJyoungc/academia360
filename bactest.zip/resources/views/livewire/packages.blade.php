<div>
    {{-- Be like water. --}}

    <div>
        {{-- Knowing others is intelligence; knowing yourself is true wisdom. --}}
        <div class="d-flex justify-content-between align-items-center flex-wrap grid-margin pb-3">
            <div>
                <h4 class="mb-3 mb-md-0">Packages</h4>
            </div>
            <div class="d-flex align-items-center flex-wrap text-nowrap">
                <button wire:click="create" class="btn btn-outline-secondary"> add</button>

                <div class="modal  fade show " @if ($modal) style="display:block;" @endif
                    id="exampleModal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
                    <div class="modal-dialog  ">
                        <div class="modal-content">
                            <div class="modal-header">
                                <h5 class="modal-title" id="exampleModalLabel"></h5>
                                <button wire:click="$set('modal', false)" type="button" class="btn-close"
                                    data-bs-dismiss="modal" aria-label="Close">
                                </button>
                            </div>
                            <div class="modal-body">
                                <div class="container">
                                    <div class="row">
                                        <div class="col-md-12">
                                            <div class="h3 text-center">Add Package</div>
                                            <form wire:submit.prevent="store">
                                                <div class="form-group">
                                                    <label for="">Name</label>
                                                    <input type="text"
                                                        class="form-control @error('Name') is-invalid @enderror "
                                                        wire:model="Name">
                                                    @error('Name')
                                                        <span class="text-danger">
                                                            {{ $message }}
                                                        </span>
                                                    @enderror

                                                </div>

                                                <div class="form-group">
                                                    <label for="">image</label>
                                                    <input type="file" wire:model="image"
                                                        class="form-control  @error('image') is-invalid @enderror">
                                                    <div wire:loading wire:target="image">
                                                        <div class="spinner-border" role="status">
                                                            <span class="visually-hidden">Loading...</span>
                                                        </div>
                                                    </div>
                                                    @error('image')
                                                        <span class="text-danger">
                                                            {{ $message }}
                                                        </span>
                                                    @enderror
                                                </div>
                                                <div class="form-group">
                                                    <label for="">Categories</label>
                                                    <select type="text"
                                                        class="form-control @error('category') is-invalid @enderror "
                                                        wire:model="category">
                                                        <option value="">Select</option>
                                                        @forelse ($categories as $item)
                                                            <option value="{{ $item->id }}">{{ $item->name }}
                                                            </option>
                                                        @empty
                                                            <option value="">EMPTY</option>
                                                        @endforelse
                                                    </select>
                                                    @error('category')
                                                        <span class="text-danger">
                                                            {{ $message }}
                                                        </span>
                                                    @enderror

                                                </div>

                                                <div class="form-group">
                                                    <label for="">Districts</label>
                                                    <select type="text"
                                                        class="form-control @error('district') is-invalid @enderror "
                                                        wire:model="district">
                                                        <option value="">Select</option>
                                                        @forelse ($districts as $item)
                                                            <option value="{{ $item->id }}">{{ $item->name }}
                                                            </option>
                                                        @empty
                                                            <option value="">EMPTY</option>
                                                        @endforelse
                                                    </select>
                                                    @error('district')
                                                        <span class="text-danger">
                                                            {{ $message }}
                                                        </span>
                                                    @enderror

                                                </div>

                                                <div class="form-group">
                                                    <label for="">Description</label>
                                                    <textarea wire:model="description" class="form-control @error('description') is-invalid @enderror " rows="5"></textarea>
                                                    @error('description')
                                                        <span class="text-danger">
                                                            {{ $message }}
                                                        </span>
                                                    @enderror
                                                </div>
                                                <div class="form-group pt-3">
                                                    <button type="submit" class="btn btn-dark form-control">
                                                        Save
                                                    </button>
                                                </div>
                                            </form>
                                        </div>


                                    </div>
                                </div>

                            </div>

                        </div>
                    </div>
                </div>


            </div>
        </div>

        <div class="card rounded-5 shadow bg-light ">
            <div class="card-body rounded-5 bg-white">
                <div class="col-md-12">
                    <div class="input-group rounded-pill  shadow  bg-body rounded">

                        <input type="text" wire:model="search" wire:keydown='query'
                            class="form-control border-0  rounded-5  " placeholder="Search...">
                    </div>

                </div>
                <div class="row pt-3">
                    <div class="col-md-12">
                        <table class="table table-hover table-responsive">
                            <thead class="thead-inverse">
                                <tr>
                                    <th>#</th>
                                    <th>Name</th>
                                    <th>Image</th>
                                    <th>category</th>
                                    <th>District</th>
                                    <th>Description</th>
                                    <th>action</th>
                                </tr>

                            <tbody>
                                @forelse ($packages as $item)
                                    <tr>
                                        <td scope="row">{{ $item->id }}</td>

                                        <td>{{ $item->name }}</td>
                                        <td>
                                            <img src="{{ asset('assets/uploads/' . $item->image->image) }}"
                                                width="50" height="50"alt="">

                                        </td>
                                        <td>{{ $item->category->name }}</td>
                                        <td>{{ $item->district->name }}</td>
                                        <td>{{ $item->description }}</td>

                                        <td>
                                            <button type="button" class="btn btn-info dropdown-toggle"
                                                data-bs-toggle="dropdown" aria-expanded="false">
                                                Options
                                            </button>
                                            <ul class="dropdown-menu">
                                                <li><a wire:click="edit({{ $item->id }})" class="dropdown-item"
                                                        href="#">Edit</a></li>
                                                <li><a wire:click="deleteit({{ $item->id }})" class="dropdown-item"
                                                        href="#">Delete</a></li>
                                            </ul>
                                        </td>
                                    </tr>
                                @empty
                                    <tr>
                                        <td colspan="6">
                                            <div class="text-center text-muted h4">EMPTY</div>
                                        </td>

                                    </tr>
                                @endforelse


                            </tbody>
                        </table>
                        <!--  Modal -->
                        <div class="modal fade show " @if ($modal2) style="display:block;" @endif
                            id="exampleModal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
                            <div class="modal-dialog">
                                <div class="modal-content">
                                    <div class="modal-header">
                                        <h5 class="modal-title" id="exampleModalLabel">Modal title</h5>
                                        <button wire:click="cancel" type="button" class="btn-close"
                                            data-bs-dismiss="modal" aria-label="Close">
                                        </button>
                                    </div>
                                    <div class="modal-body">
                                        <div class="container">
                                            <div class="row">
                                                <div class="col-md-12">
                                                    <div class="h3 text-center">Edit Package</div>
                                                    <form wire:submit.prevent="update">
                                                        <div class="form-group">
                                                            <label for="">Name</label>
                                                            <input type="text"
                                                                class="form-control @error('Name') is-invalid @enderror "
                                                                wire:model="Name">
                                                            @error('Name')
                                                                <span class="text-danger">
                                                                    {{ $message }}
                                                                </span>
                                                            @enderror

                                                        </div>

                                                        <div class="form-group">
                                                            <label for="">image</label>
                                                            <input type="file" wire:model="image"
                                                                class="form-control  @error('image') is-invalid @enderror">
                                                            <div wire:loading wire:target="image">
                                                                <div class="spinner-border" role="status">
                                                                    <span class="visually-hidden">Loading...</span>
                                                                </div>
                                                            </div>
                                                            @error('image')
                                                                <span class="text-danger">
                                                                    {{ $message }}
                                                                </span>
                                                            @enderror
                                                        </div>
                                                        <div class="form-group">
                                                            <label for="">Categories</label>
                                                            <select type="text"
                                                                class="form-control @error('category') is-invalid @enderror "
                                                                wire:model="category">
                                                                <option value="">Select</option>
                                                                @forelse ($categories as $item)
                                                                    <option value="{{ $item->id }}">
                                                                        {{ $item->name }}</option>
                                                                @empty
                                                                    <option value="">EMPTY</option>
                                                                @endforelse
                                                            </select>
                                                            @error('category')
                                                                <span class="text-danger">
                                                                    {{ $message }}
                                                                </span>
                                                            @enderror

                                                        </div>

                                                        <div class="form-group">
                                                            <label for="">Districts</label>
                                                            <select type="text"
                                                                class="form-control @error('district') is-invalid @enderror "
                                                                wire:model="district">
                                                                <option value="">Select</option>
                                                                @forelse ($districts as $item)
                                                                    <option value="{{ $item->id }}">
                                                                        {{ $item->name }}</option>
                                                                @empty
                                                                    <option value="">EMPTY</option>
                                                                @endforelse
                                                            </select>
                                                            @error('district')
                                                                <span class="text-danger">
                                                                    {{ $message }}
                                                                </span>
                                                            @enderror

                                                        </div>

                                                        <div class="form-group">
                                                            <label for="">Description</label>
                                                            <textarea wire:model="description" class="form-control @error('description') is-invalid @enderror " rows="5"></textarea>
                                                            @error('description')
                                                                <span class="text-danger">
                                                                    {{ $message }}
                                                                </span>
                                                            @enderror
                                                        </div>
                                                        <div class="form-group pt-3">
                                                            <button type="submit" class="btn btn-dark form-control">
                                                                Save
                                                            </button>
                                                    </form>

                                                </div>
                                            </div>


                                        </div>
                                    </div>

                                </div>

                            </div>
                        </div>
                    </div>

                </div>
            </div>
        </div>




    </div>


</div>

</div>
