<div>
    {{-- If your happiness depends on money, you will never be happy with yourself. --}}
    <div>
        {{-- A good traveler has no fixed plans and is not intent upon arriving. --}}
        <div>
            {{-- Be like water. --}}

            <div>
                {{-- Knowing others is intelligence; knowing yourself is true wisdom. --}}
                <div class="d-flex justify-content-between align-items-center flex-wrap grid-margin pb-3">
                    <div>
                        <h4 class="mb-3 mb-md-0">Booking</h4>
                    </div>
                    {{-- <div class="d-flex align-items-center flex-wrap text-nowrap">
                        <button wire:click="create" class="btn btn-outline-secondary"> add</button> --}}

                    <div class="modal  fade show " @if ($modal) style="display:block;" @endif
                        id="exampleModal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
                        <div class="modal-dialog ">
                            <div class="modal-content">
                                <div class="modal-header">
                                    <h5 class="modal-title" id="exampleModalLabel"></h5>
                                    <button wire:click="$set('modal', false)" type="button" class="btn-close"
                                        data-bs-dismiss="modal" aria-label="Close">
                                    </button>
                                </div>
                                <div class="modal-body">
                                    <div class="container">
                                        <div class="row">
                                            <div class="col-md-12">
                                                <div class="h3 text-center">Add Room</div>


                                                <div class="form-group">
                                                    <label for="">Description</label>
                                                    <textarea wire:model="description" class="form-control @error('description') is-invalid @enderror " rows="5"></textarea>
                                                    @error('description')
                                                        <span class="text-danger">
                                                            {{ $message }}
                                                        </span>
                                                    @enderror
                                                </div>
                                                <div class="form-group pt-1">
                                                    <button wire:click="store" class="btn btn-dark form-control">
                                                        Save
                                                    </button>
                                                </div>
                                            </div>


                                        </div>
                                    </div>

                                </div>

                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <div class="card rounded-5 shadow bg-light ">
                <div class="card-body rounded-5 bg-white">
                    <div class="col-md-12">
                        <div class="input-group rounded-pill  shadow  bg-body rounded">

                            <input type="text" wire:model="search" wire:keydown='query'
                                class="form-control border-0  rounded-5  " placeholder="Search...">
                        </div>

                    </div>
                    <div class="row pt-3">
                        <div class="col-md-12">
                            <table class="table table-hover table-inverse table-responsive">
                                <thead class="thead-inverse">
                                    <tr>
                                        <th>#</th>
                                        <th>Image</th>
                                        <th>Name</th>
                                        <th>Package</th>
                                        <th>Description</th>
                                        <th>Price</th>
                                        <th>Action</th>
                                    </tr>

                                <tbody>
                                    @forelse ($rooms as $item)
                                        <tr>
                                            <td scope="row">{{ $item->id }}</td>
                                            <td>
                                                <img src="{{ url('storage/' . $item->image) }}" width="50"
                                                    height="50"alt="">
                                            </td>
                                            <td>{{ $item->room_type }}</td>
                                            <td>{{ $item->package->name }} {{ $item->package->district->name }}
                                            </td>

                                            <td>{{ $item->description }}</td>
                                            <td>MWK {{ $item->price }} .00</td>
                                            <td>

                                                <button type="button" class="btn btn-primary dropdown-toggle"
                                                    data-bs-toggle="dropdown" aria-expanded="false">
                                                    Options
                                                </button>
                                                <ul class="dropdown-menu">
                                                    <li><a wire:click="edit({{ $item->id }})" class="dropdown-item"
                                                            href="#">Edit</a></li>
                                                    <li><a wire:click="deleteit({{ $item->id }})"
                                                            class="dropdown-item" href="#">Delete</a></li>
                                                </ul>
                                            </td>
                                        </tr>
                                    @empty
                                        <tr>
                                            <td colspan="6">
                                                <div class="text-center text-muted h4">EMPTY</div>
                                            </td>

                                        </tr>
                                    @endforelse


                                </tbody>
                            </table>
                            <!-- Token Value Modal -->
                            <div class="modal fade show "
                                @if ($modal2) style="display:block;" @endif id="exampleModal"
                                tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
                                <div class="modal-dialog">
                                    <div class="modal-content">
                                        <div class="modal-header">
                                            <h5 class="modal-title" id="exampleModalLabel"></h5>
                                            <button wire:click="cancel" type="button" class="btn-close"
                                                data-bs-dismiss="modal" aria-label="Close">
                                            </button>
                                        </div>
                                        <div class="modal-body">
                                            <div class="container">
                                                <div class="row">
                                                    <div class="col-md-12">
                                                        <div class="h3 text-center">Edit Room</div>

                                                        <div class="form-group">
                                                            <label for="">Type</label>
                                                            <input type="text"
                                                                class="form-control @error('type') is-invalid @enderror "
                                                                wire:model="type">
                                                            @error('type')
                                                                <span class="text-danger">
                                                                    {{ $message }}
                                                                </span>
                                                            @enderror

                                                        </div>

                                                        <div class="form-group">
                                                            <label for="">image</label>
                                                            <input type="file" wire:model="image"
                                                                class="form-control  @error('image') is-invalid @enderror">
                                                            @error('image')
                                                                <span class="text-danger">
                                                                    {{ $message }}
                                                                </span>
                                                            @enderror
                                                        </div>

                                                        <div class="form-group">
                                                            <label for="">Packages</label>
                                                            <select type="text"
                                                                class="form-control @error('package') is-invalid @enderror "
                                                                wire:model="package">
                                                                <option value="">Select</option>
                                                                @forelse ($packages as $item)
                                                                    <option value="{{ $item->id }}">
                                                                        {{ $item->name }}
                                                                        {{ $item->district->name }}
                                                                    </option>
                                                                @empty
                                                                    <option value="">EMPTY</option>
                                                                @endforelse
                                                            </select>
                                                            @error('package')
                                                                <span class="text-danger">
                                                                    {{ $message }}
                                                                </span>
                                                            @enderror

                                                        </div>

                                                        <div class="form-group">
                                                            <label for="">Price</label>
                                                            <input type="text"
                                                                class="form-control @error('price') is-invalid @enderror "
                                                                wire:model="price">
                                                            @error('price')
                                                                <span class="text-danger">
                                                                    {{ $message }}
                                                                </span>
                                                            @enderror

                                                        </div>
                                                        <div class="form-group">
                                                            <label for="">Description</label>
                                                            <textarea wire:model="description" class="form-control @error('description') is-invalid @enderror " rows="5"></textarea>
                                                            @error('description')
                                                                <span class="text-danger">
                                                                    {{ $message }}
                                                                </span>
                                                            @enderror
                                                        </div>
                                                        <div class="form-group pt-1">
                                                            <button wire:click="update"
                                                                class="btn btn-dark form-control">
                                                                Save
                                                            </button>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

</div>
