@extends('layouts.root2')
@section('content')
    <main id="main" class="margin-top-100">
        <!-- ======= About Us Section ======= -->
        <section id="about" class="about">
            <div class="container" data-aos="fade-up">

                <div class="section-title">
                    <h2>ABOUT US</h2>
                </div>

                <div class="row content">
                    <div class="col-lg-12">
                        <p>BCA Travel Limited is a professional
                            brand in the tourism industry
                            dedicated to providing reliable,
                            best, and cost-effective tour and
                            travel solutions to our clients.
                            Concentrating on both corporate
                            and individual travel
                            arrangements, we offer expertise
                            in Air Ticketing and Reservations,
                            Hotel Reservations, Tours and
                            Holiday Packages, Travel
                            Insurance, Tailor made packages,
                            Visa applications and Travel advice.
                            The combination of our
                            experienced team and our
                            commitment to customer
                            satisfaction assures delivery of a
                            safe, memorable and hustle free
                            travel experience for our clientele</p>
                    </div>

                </div>

            </div>
        </section>
        <!-- End About Us Section -->

        <!-- ======= Why Us Section ======= -->
        <section id="why-us" class="why-us">
            <div class="container-fluid">

                <div class="row">

                    <div class="col-lg-5 align-items-stretch position-relative video-box"
                        style='background-image: url("{{ url('public/assets/img/why-us.jpg') }}");' data-aos="fade-right">
                        {{-- <a href="https://www.youtube.com/watch?v=LXb3EKWsInQ" class="glightbox play-btn mb-4"></a> --}}
                    </div>

                    <div class="col-lg-7 d-flex flex-column justify-content-center align-items-stretch"
                        data-aos="fade-left">

                        <div class="content">
                            <h3>More About Us</h3>

                        </div>

                        <div class="accordion-list">
                            <ul>
                                <li data-aos="fade-up" data-aos-delay="100">
                                    <a data-bs-toggle="collapse" class="collapse"
                                        data-bs-target="#accordion-list-1"><span>01</span> Flexibility <i
                                            class="bx bx-chevron-down icon-show"></i><i
                                            class="bx bx-chevron-up icon-close"></i></a>
                                    <div id="accordion-list-1" class="collapse show" data-bs-parent=".accordion-list">
                                        <p>
                                            We are firm
                                            believers of the notion the
                                            customer is King. As such, we
                                            take into serious consideration
                                            our customers views and
                                            opinions to ensure what the
                                            customer wants, the customer
                                            gets.
                                        </p>
                                    </div>
                                </li>

                                <li data-aos="fade-up" data-aos-delay="200">
                                    <a data-bs-toggle="collapse" data-bs-target="#accordion-list-2"
                                        class="collapsed"><span>02</span> Accountability And Transparency <i
                                            class="bx bx-chevron-down icon-show"></i><i
                                            class="bx bx-chevron-up icon-close"></i></a>
                                    <div id="accordion-list-2" class="collapse" data-bs-parent=".accordion-list">
                                        <p>
                                            throughout our
                                            relations with our clients to
                                            ensure we gain their trust.
                                        </p>
                                    </div>
                                </li>

                                <li data-aos="fade-up" data-aos-delay="300">
                                    <a data-bs-toggle="collapse" data-bs-target="#accordion-list-3"
                                        class="collapsed"><span>03</span>Honesty <i
                                            class="bx bx-chevron-down icon-show"></i><i
                                            class="bx bx-chevron-up icon-close"></i></a>
                                    <div id="accordion-list-3" class="collapse" data-bs-parent=".accordion-list">
                                        <p>
                                            is the backbone of
                                            our operations as we believe in
                                            serving our customers with
                                            fairness.
                                        </p>
                                    </div>
                                </li>

                                <li data-aos="fade-up" data-aos-delay="300">
                                    <a data-bs-toggle="collapse" data-bs-target="#accordion-list-4"
                                        class="collapsed"><span>04</span>Team work <i
                                            class="bx bx-chevron-down icon-show"></i><i
                                            class="bx bx-chevron-up icon-close"></i></a>
                                    <div id="accordion-list-4" class="collapse" data-bs-parent=".accordion-list">
                                        <p>
                                            We believe that no man is an
                                            island hence we believe in
                                            Team work when providing
                                            our services
                                        </p>
                                    </div>
                                </li>

                                <li data-aos="fade-up" data-aos-delay="300">
                                    <a data-bs-toggle="collapse" data-bs-target="#accordion-list-5"
                                        class="collapsed"><span>05</span>Professionalism and Reliability <i
                                            class="bx bx-chevron-down icon-show"></i><i
                                            class="bx bx-chevron-up icon-close"></i></a>
                                    <div id="accordion-list-5" class="collapse" data-bs-parent=".accordion-list">
                                        <p>
                                            Exceptional management
                                            which operates with
                                            Professionalism and
                                            Reliability to the client.
                                        </p>
                                    </div>
                                </li>
                                <li data-aos="fade-up" data-aos-delay="300">
                                    <a data-bs-toggle="collapse" data-bs-target="#accordion-list-6"
                                        class="collapsed"><span>06</span>Innovation. <i
                                            class="bx bx-chevron-down icon-show"></i><i
                                            class="bx bx-chevron-up icon-close"></i></a>
                                    <div id="accordion-list-6" class="collapse" data-bs-parent=".accordion-list">
                                        <p>
                                            We believe that
                                            there is always room for
                                            improvement hence we don’t
                                            settle for the status quo. When
                                            it comes to quality service
                                            provision, we always aim to get
                                        </p>
                                    </div>
                                </li>

                            </ul>
                        </div>

                    </div>

                </div>

            </div>
        </section>
        <!-- End Why Us Section -->


        <!-- ======= Team Section ======= -->
        <section id="team" class="team section-bg">
            <div class="container" data-aos="fade-up">

                <div class="section-title">
                    <h2>Team</h2>
                    <p></p>
                </div>

                <div class="row">
                    <div class="col-lg-4 mt-4 pt-2 " data-aos="fade-up" data-aos-delay="200">

                        <div class="card shadow border-0 bg-light ">
                            <div class="card-body ">
                                <div class=" row justify-content-center">
                                    <div class="col-md-4">
                                        <img src="{{ url('public/assets/img/team/team-1.jpg') }}"
                                            class="img-fluid rounded-circle" alt="">
                                    </div>
                                </div>
                                <div class="row justify-content-center">
                                    <div class="col-md-12 text-center">
                                        <h4 class="title">Fank Banda</h4>
                                        <span>Director</span>
                                        <p>
                                            E: frank.banda@bcatravel.com <br>
                                            C: +353 899 663 905
                                        </p>

                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-4 mt-4 pt-2 " data-aos="fade-up" data-aos-delay="200">

                        <div class="card shadow border-0 bg-light ">
                            <div class="card-body ">
                                <div class=" row justify-content-center">
                                    <div class="col-md-4">
                                        <img src="{{ url('public/assets/img/team/team-2.jpg') }}"
                                            class="img-fluid rounded-circle" alt="">
                                    </div>
                                </div>
                                <div class="row justify-content-center">
                                    <div class="col-md-12 text-center">
                                        <h4 class="title">Davison Ching’onga Banda</h4>
                                        <span>Director</span>
                                        <p>
                                            E:davison@bcatravel.com <br>
                                            C: +265 991 807 145
                                        </p>

                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>

                    <div class="col-lg-4 mt-4 pt-2 " data-aos="fade-up" data-aos-delay="200">

                        <div class="card shadow border-0 bg-light ">
                            <div class="card-body ">
                                <div class=" row justify-content-center">
                                    <div class="col-md-4">
                                        <img src="{{ url('public/assets/img/team/team-3.jpg') }}"
                                            class="img-fluid rounded-circle" alt="">
                                    </div>
                                </div>
                                <div class="row justify-content-center">
                                    <div class="col-md-12 text-center">
                                        <h4 class="title">Bertha Mponda</h4>
                                        <span>Director</span>
                                        <p>
                                            E:davison@bcatravel.com <br>
                                            C: +265 991 807 145
                                        </p>

                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>

                    <div class="col-lg-4 mt-4 pt-2 " data-aos="fade-up" data-aos-delay="200">

                        <div class="card shadow border-0 bg-light ">
                            <div class="card-body ">
                                <div class="row justify-content-center">
                                    <div class="col-md-4">
                                        <img src="{{ url('public/assets/img/team/team-4.jpg') }}"
                                            class="img-fluid rounded-circle" alt="">
                                    </div>
                                </div>
                                <div class="row justify-content-center">
                                    <div class="col-md-12 text-center">
                                        <h4 class="title">Watipaso Chilinda</h4>
                                        <span>Marketing Officer</span>
                                        <p>Implements marketing activities
                                            and communications in order to
                                            keep clients updated with latest
                                            offers and packages <br>
                                            E: berthamponda@bcatravel.com <br>
                                            C: +265 886 400 694 <br></p>

                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>


                    <div class="col-lg-4 mt-4 pt-2 " data-aos="fade-up" data-aos-delay="200">

                        <div class="card shadow border-0 bg-light ">
                            <div class="card-body ">
                                <div class="row justify-content-center">
                                    <div class="col-md-4">
                                        <img src="{{ url('public/assets/img/team/team-1.jpg') }}"
                                            class="img-fluid rounded-circle" alt="">
                                    </div>
                                </div>
                                <div class="row justify-content-center">
                                    <div class="col-md-12 text-center">
                                        <h4 class="title">Kellington Simbota</h4>
                                        <span>Marketing Officer</span>
                                        <p>Provides expertise on company
                                            strategy as well as marketing <br>
                                            E: kellington@bca.com <br>
                                            C: +265 982 858 373

                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>


                </div>

            </div>
        </section>
        <!-- End Team Section -->



        <!-- ======= Cta Section ======= -->
        <section id="cta" class="cta">
            <div class="container">

                <div class="row" data-aos="zoom-in">

                    <div class="col-lg-4 ">
                        <h3 class="text-center">MISSION
                            STATEMENT</h3>
                        <p> To satisfy our customers by
                            providing efficient, innovative, and
                            affordable travel services while
                            keeping our employees motivated
                            to serve our customers.</p>
                    </div>
                    <div class="col-lg-4 text-center">
                        <h3 class="text-center">VISION</h3>
                        <p> To be Malawi’s most trusted travel
                            agency in affordable and innovative
                            travel packages</p>

                    </div>
                    <div class="col-lg-4 text-center">
                        <h3 class="text-center">OPERATING
                            PRINCIPALS
                            AND VALUES</h3>
                        <p>At BCA Travel Limited we highly
                            believe in prioritizing customer
                            satisfaction and delivering world
                            class service to our clients. As such
                            we operate under the following
                            core values:</p>
                    </div>

                </div>

            </div>
        </section>
        <!-- End Cta Section -->
    </main>
@endsection
