<div>
    {{-- In work, do what you enjoy. --}}
    <main id="main" class="margin-top-100 grad-back">
        <section>
            <div class="container-fluid " >
                <div class="section-title">
                    <h2 class="text-light">{{ $package->name }} </h2>
                    <p></p>

                    <div>
                        {{-- Be like water. --}}
                        <div class="row justify-content-center">
                            <div class="col-md-8">
                                <div class="input-group rounded-pill mb-3 shadow-sm p-3 bg-body rounded">
                                    <span class="input-group-text text-muted bg-white border-0"> <i
                                            class="ri-search-line"></i></span>
                                    <input type="text" wire:model.prevent="search"
                                        class="form-control border-0  rounded-5 me-4 " placeholder="Search...">
                                </div>

                            </div>
                        </div>
                        <div class="row">

                            @forelse ($listings as $item)
                                <div class="col-lg-6 col-md-12"  >
                                    <a class="text-dark" href="{{ route('root.book.listing', $item->id) }}">

                                        <div class="card shadow bg-light">
                                            <div class="card-body">
                                                <div class="d-flex flex-column">
                                                    <div class="d-flex">
                                                        {{-- <img src="{{ asset('assets/img/blog/blog-recent-2.jpg') }}"
                                                            width="100" height="100" alt=""> --}}
                                                        <div class="d-flex w-100 flex-column ps-3">
                                                            <div class="d-flex  justify-content-between">
                                                                <h5 class="text-dark">
                                                                    @if ($item->flight_international == '')
                                                                        {{ $item->from->name }} -
                                                                        {{ $item->to->name }}
                                                                    @else
                                                                        {{ $item->ifrom->name }} -
                                                                        {{ $item->ito->name }}
                                                                    @endif

                                                                    (@if ($item->flight_international == '')
                                                                        <small>local</small>
                                                                    @else
                                                                        <small>international</small>
                                                                    @endif)
                                                                    </h4>
                                                                    <span class="fw-bold">MkW {{ $item->price }}
                                                                        .00</span>
                                                            </div>
                                                            <span>{{ $item->package->name }}</span>
                                                            <span>{{ $item->flight_departure . ' - ' . $item->flight_arrival }}</span>
                                                            <span>{{ $item->description }}</span>

                                                            <div class=" justify-content-center">
                                                                <div class="btn btn-primary col-md-12 col-lg-6">
                                                                    Book Now</div>
                                                            </div>

                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>


                                    </a>

                                </div>
                            @empty


                                <div class="col-lg-12 p-2">
                                    <div class="card shadow bg-light">
                                        <div class="card-body">
                                            <div class="h2 text-center text-muted">Empty</div>
                                        </div>
                                    </div>
                                </div>
                            @endforelse


                        </div>
                    </div>
                </div>
            </div>
        </section>
    </main>
</div>
