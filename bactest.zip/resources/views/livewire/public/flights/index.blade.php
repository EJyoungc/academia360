@extends('layouts.root2')
@section('content')
    <div>
        {{-- The Master doesn't talk, he acts. --}}

        <section id="hero2" style="background: url('../img/hero-bg.jpg') top center;"
            class="d-flex justify-cntent-center align-items-center">
            <div class="container">
                <div class="row justify-content-center" data-aos="fade-up">
                    <div class="col-md-7  text-white text-center ">
                        <div class=" fw-bold display-1 ">FLIGHTS</div>
                        <p>
                            Get the latest fight updates
                        </p>
                    </div>
                </div>
            </div>
        </section><!-- End Hero -->

        <main id="main">

            <!-- ======= Icon Boxes Section ======= -->
            <section id="icon-boxes" class="icon-boxes">
                <div class="container">

                    <div class="row">
                        <div class="col-md-12 col-lg-12  align-items-stretch mb-lg-0" data-aos="fade-up">

                        </div>
                    </div>

                </div>
            </section><!-- End Icon Boxes Section -->
            <!-- ======= flights Section ======= -->
            <section id="pricing" class="pricing">
                <div class="container" data-aos="fade-up">

                    @livewire('components.public-flights')
                </div>
            </section>
            <!-- End flights Section -->




        </main><!-- End #main -->
    @endsection
