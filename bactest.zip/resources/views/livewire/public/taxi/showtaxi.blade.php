<div>
    {{-- In work, do what you enjoy. --}}
    <main id="main" class="margin-top-100 grad-back ">
        <section>
            <div class="container-fluid ">
                <div class="section-title">
                    <h2 class="text-white">{{ $package->name }} </h2>
                    <p></p>

                    <div>
                        {{-- Be like water. --}}


                        <div class="row justify-content-center">
                            <div class="col-md-8">
                                <div class="input-group col-md-8 rounded-pill mb-3 shadow-sm p-3 bg-body rounded">
                                    <span class="input-group-text text-muted bg-white border-0"> <i
                                            class="ri-search-line"></i></span>
                                    <input type="text" wire:model.prevent="search"
                                        class="form-control border-0  rounded-5 me-4 " placeholder="Search...">
                                </div>
                            </div>
                            <div class="row">
                                @forelse ($listings as $item)
                                    <div class="col-lg-4 col-md-6">

                                        <a href="{{ route('root.book.listing', $item->id) }}" class="text-dark">

                                            <div class="card shadow bg-light">
                                                <div class="card-body">
                                                    <div class="d-flex flex-column">
                                                        <div class="d-flex">
                                                            <img src="{{ asset('storage/' . $item->package->image->image) }}"
                                                                width="100" height="100" alt="">
                                                            <div
                                                                class="d-flex w-100 flex-column justify-content-start ps-3">
                                                                <div class="d-flex  justify-content-between">
                                                                    <h5 class="text-dark">{{ $item->package->name }}
                                                                    </h5>
                                                                    <span class="fw-bold">MWK {{ $item->price }}.00
                                                                    </span>
                                                                </div>
                                                                <div class="d-flex justify-content-start">
                                                                    <span>{{ $item->taxi_driver_name }}</span>
                                                                </div>
                                                                <div class="d-flex justify-content-start">
                                                                    <span>{{ $item->description }}</span>
                                                                </div>
                                                                <div class="d-flex justify-content-end">
                                                                    <div class="btn btn-primary col-md-6">
                                                                        Book now
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </a>
                                    </div>
                                @empty
                                    <div class="col-lg-12 p-2">
                                        <div class="card shadow bg-light">
                                            <div class="card-body text-center ">
                                                <h4 class="text-muted">EMPTY</h4>
                                            </div>
                                        </div>
                                    </div>
                                @endforelse


                            </div>



                        </div>

                    </div>



                </div>


            </div>
        </section>
    </main>
</div>
