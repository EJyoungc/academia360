@extends('layouts.root2')


@section('content')
    <div>
        {{-- The Master doesn't talk, he acts. --}}

        <section id="hero2" style="background: url('../img/hero-bg.jpg') top center;"
            class="d-flex justify-cntent-center align-items-center">
            <div class="container">
                <div class="row justify-content-center" data-aos="fade-up">
                    <div class="col-md-7  text-white text-center ">
                        <div class=" fw-bold display-1 ">Airport Taxi</div>
                        <p>
                            We will provide with the highest quality transport
                        </p>
                    </div>
                </div>
            </div>
        </section><!-- End Hero -->

        <main id="main ">


            <!-- ======= flights Section ======= -->
            <section id="pricing" class=" margin-top-100  pricing grad-back">
                <div class="container" data-aos="fade-up">


                    @livewire('components.public-taxis')

                </div>
            </section>
            <!-- End flights Section -->




        </main><!-- End #main -->
    @endsection
