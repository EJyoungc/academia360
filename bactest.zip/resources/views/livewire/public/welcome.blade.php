<div>
    {{-- The Master doesn't talk, he acts. --}}

    <div class="icon-box">
        <div class="row">
            <div class="col-md-12">
                <form action="">
                    <div class="row">

                        <div class="col-md-12">
                            <div class="input-group rounded-pill mb-3 shadow-lg p-3 bg-body rounded">
                                <span class="input-group-text text-muted bg-white border-0"> <i
                                        class="ri-search-line"></i></span>
                                <input type="text" wire:model.lazy="location" wire:keydown='query'
                                    class="form-control border-0  rounded-5 me-4 " placeholder="Search...">
                            </div>

                        </div>
                    </div>
                </form>
            </div>
        </div>
        @if (!empty($location))
            <div class="row pt-3">
                <div class="col-md-12">

                    <div class="list-group">
                        @forelse($results as $item)
                            <a href="#" class="list-group-item list-group-item-action">
                                <div class="d-flex">
                                    <img src="{{ url('storage/' . $item->image->image) }}" width="80" height="80"
                                        alt="" srcset="">
                                    <div class=" flex-column w-100 align-items-start ">
                                        <div class="d-flex  justify-content-between">
                                            <h5 class="mb-1 pe-1 pt-1">{{ $item->name }}</h5>
                                            <small>{{ $item->location->coordinates }}</small>
                                        </div>
                                        <p class="mb-1">{{ $item->description }}</p>
                                        <small> MWK<span class="text-primary"> {{ $item->price }}.00</span></small>
                                    </div>
                                </div>

                            </a>
                        @empty
                            <a href="#" class="list-group-item list-group-item-action">
                                <div class="text-center text-muted">EMPTY</div>
                            </a>
                        @endforelse

                    </div>
                </div>
            </div>
        @endif

    </div>
</div>
