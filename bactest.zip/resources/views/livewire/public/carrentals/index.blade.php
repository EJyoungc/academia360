@extends('layouts.root2')


@section('content')
    <div>
        {{-- The Master doesn't talk, he acts. --}}

        <section id="hero2" style="background: url('../img/hero-bg.jpg') top center;"
            class="d-flex justify-cntent-center align-items-center">
            <div class="container">
                <div class="row justify-content-center" data-aos="fade-up">
                    <div class="col-md-7  text-white text-center ">
                        <div class=" fw-bold display-1 ">Car Rentals</div>
                        <p>
                            Want to rent a car ?
                        </p>
                    </div>
                </div>
            </div>
        </section><!-- End Hero -->

        <main id="main "class="margin-top-100 grad-back">


            <section id="pricing" class="pricing">
                <div class="container" data-aos="fade-up">


                    @livewire('components.public-carrentals')

                </div>
            </section>
            <!-- End flights Section -->




        </main><!-- End #main -->
    @endsection
