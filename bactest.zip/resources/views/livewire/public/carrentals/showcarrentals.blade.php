<div>
    {{-- In work, do what you enjoy. --}}
    <main id="main" class="margin-top-100">
        <section>
            <div class="container-fluid ">
                <div class="section-title">
                    <h2>{{ $package->name }} </h2>
                    <p></p>

                    <div>
                        {{-- Be like water. --}}

                        <div class="row justify-content-center">
                            <div class="col-md-8">
                                <div class="input-group rounded-pill mb-3 shadow-sm p-3 bg-body rounded">
                                    <span class="input-group-text text-muted bg-white border-0"> <i
                                            class="ri-search-line"></i></span>
                                    <input type="text" wire:model="search"
                                        class="form-control border-0  rounded-5 me-4 " placeholder="Search...">
                                </div>

                            </div>
                        </div>

                        <div class="row pt-3">



                            @forelse($listings as $item)
                                <div class="col-sm-4">
                                    <a href="{{ route('root.book.listing', $item->id) }}" class="">
                                        <div class="card1 card_three text-center">
                                            <img src="{{ url('storage/' . $item->image) }}" class="card-img-top"
                                                alt="...">
                                            <div class="card-body ">
                                                <div class="title">
                                                    <i class="fa fa-rocket" aria-hidden="true"></i>
                                                    <h2>{{ $item->car_rental_type }}</h2>
                                                </div>
                                                <div class="price">
                                                    <h5><sup>MWK</sup> {{ $item->price }}
                                                        .00</h5>
                                                </div>
                                                <div class="option pb-3">
                                                    <ul>

                                                        <li>{{ $item->package->name }}
                                                        </li>
                                                        <li>{{ $item->description }}
                                                        </li>
                                                        <button class="btn btn-outline-success">Book now</button>
                                                    </ul>
                                                </div>

                                            </div>

                                        </div>
                                    </a>
                                </div>

                            @empty
                                <div class="col-lg-12 p-2">
                                    <div class="card shadow bg-light">
                                        <div class="card-body">
                                            <div class="h4 text-muted">EMPTY</div>
                                        </div>
                                    </div>
                                </div>
                            @endforelse

                        </div>




                    </div>



                </div>


            </div>
        </section>
    </main>
</div>
