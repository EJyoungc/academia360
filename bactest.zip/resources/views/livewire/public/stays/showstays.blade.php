<div>
    {{-- In work, do what you enjoy. --}}
    <main id="main" class="margin-top-100">
        <section>
            <div class="container-fluid ">
                <div class="section-title">
                    <h2>{{ $package->name }} </h2>
                    <p></p>

                    <div>
                        {{-- Be like water. --}}
                        <div class="row justify-content-center">
                            <div class="col-md-8">
                                <div class="input-group rounded-pill mb-3 shadow-sm p-3 bg-body rounded">
                                    <span class="input-group-text text-muted bg-white border-0"> <i
                                            class="ri-search-line"></i></span>
                                    <input type="text" wire:model.prevent="search"
                                        class="form-control border-0  rounded-5 me-4 " placeholder="Search...">
                                </div>

                            </div>
                        </div>

                        <div class="row ">


                            @forelse($listings as $item)
                                <div class="col-lg-4">

                                    <div class="card text-bg-dark">
                                        <img src="{{ url('storage/' . $item->image) }}" class="card-img img-style"
                                            alt="...">
                                        <div class="card-img-overlay p-0 overlay">
                                            <div class="card-body text">
                                                <h4>{{ $item->room_type }}</h4>
                                                <p class="fw-bold">MKW {{ $item->price }}.00</p>
                                                <p>{{ $item->description }}</p>
                                                <p>
                                                    <a href="{{ route('root.book.listing', $item->id) }}"
                                                        class="btn btn-outline-light"> Book Now <i
                                                            class="ri-paypal-fill"></i></a>
                                                </p>

                                                <a href="{{ url('storage/' . $item->image) }}"
                                                    data-gallery="portfolioGallery" class="text-light preview-link"
                                                    title="Book"><i class="ri-eye-fill"></i></a>
                                            </div>
                                        </div>
                                    </div>

                                </div>


                                {{-- <div class="col-lg-4 col-md-6 col-sm-12  portfolio-item wild-life">
                                    <img src="{{ url('storage/' . $item->image) }}" class="img-style" alt="">
                                    <div class="portfolio-info">
                                        <h4>{{ $item->room_type }}</h4>
                                        <p class="fw-bold">MKW {{ $item->price }}.00</p>
                                        <p>{{ $item->description }}</p>
                                        <p>
                                            <a href="{{ route('root.book.listing', $item->id) }}"
                                                class="btn btn-outline-light"> Book Now <i
                                                    class="ri-paypal-fill"></i></a>
                                        </p>

                                        <a href="{{ url('storage/' . $item->image) }}" data-gallery="portfolioGallery"
                                            class="portfolio-lightbox preview-link" title="Book"><i
                                                class="ri-eye-fill"></i></a>

                                    </div>
                                </div> --}}
                            @empty

                                <div class="col-lg-12 col-md-12 col-sm-12 ">
                                    <div class="card">
                                        <div class="card-body">
                                            <div class="h4 text-center text-muted">
                                                EMPTY
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            @endforelse

                        </div>
                    </div>



                </div>


            </div>
        </section>
    </main>
</div>
