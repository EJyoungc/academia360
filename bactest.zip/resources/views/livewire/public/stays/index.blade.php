@extends('layouts.root2')
@section('content')
    <section id="hero2" style="background: url('../img/hero-bg.jpg') top center;"
        class="d-flex justify-cntent-center align-items-center">
        <div class="container">
            <div class="row justify-content-center" data-aos="fade-up">
                <div class="col-md-7  text-white text-center ">
                    <div class=" fw-bold display-1 ">Stays</div>
                    <p>
                        Get the latest stays updates
                    </p>
                </div>
            </div>
        </div>
    </section><!-- End Hero -->



    <main id="main" class="margin-top-100 grad-back">

        <div class="container " data-aos="fade-up">

            @livewire('components.public-stays')

        </div>

    </main>
@endsection
