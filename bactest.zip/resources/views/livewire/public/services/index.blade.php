@extends('layouts.root2')
@section('content')
    <main id="main" class="margin-top-100">

        <!-- ======= Services Section ======= -->
        <section id="services" class="services">
            <div class="container" data-aos="fade-up">

                <div class="section-title">
                    <h2>Our Services</h2>
                    <p></p>
                </div>

                <div class="row">
                    <div class="col-md-6 d-flex align-items-stretch" data-aos="fade-up" data-aos-delay="100">
                        <div class="icon-box">
                            <i class="bi bi-card-checklist"></i>
                            <h4><a href="#">AIR TICKETING AND RESERVATIONS</a></h4>
                            <p>With the use of cutting
                                edge online e booking
                                system Galileo,we ensure
                                our clients are up to date
                                with airline information
                                and process bookings and
                                reservations for a desired
                                destination both local and
                                international flights
                            </p>
                        </div>
                    </div>
                    <div class="col-md-6 d-flex align-items-stretch mt-4 mt-md-0" data-aos="fade-up" data-aos-delay="200">
                        <div class="icon-box">
                            <i class="bi bi-bar-chart"></i>
                            <h4><a href="#">TRAVEL INSURANCE</a></h4>
                            <p>In collaboration with our
                                partners, we offer insurance
                                cover for travel clients to
                                ensure safety.</p>
                        </div>
                    </div>
                    <div class="col-md-6 d-flex align-items-stretch mt-4 mt-md-0" data-aos="fade-up" data-aos-delay="300">
                        <div class="icon-box">
                            <i class="bi bi-binoculars"></i>
                            <h4><a href="#">TOURS AND TAILOR
                                    MADE HOLIDAY
                                    PACKAGES</a></h4>
                            <p>We arrange local and
                                international tours be it lake
                                tours, safaris, museums
                                historical sites and
                                mountain hikes for
                                individuals or groups as per
                                arranged iteneraries for
                                both in bound and out
                                bound tours. We offer travel
                                package to honeymooners,
                                family vacations as well as
                                corporate clients</p>
                        </div>
                    </div>
                    <div class="col-md-6 d-flex align-items-stretch mt-4 mt-md-0" data-aos="fade-up" data-aos-delay="400">
                        <div class="icon-box">
                            <i class="bi bi-brightness-high"></i>
                            <h4><a href="#">TRAVEL ADVICE</a></h4>
                            <p>We have sufficient
                                expertise that enables us to
                                to give clients travel
                                information and data
                                including destination recommendations, travel
                                requirements and
                                documents and all
                                relevant information to
                                ensure travel comfort
                                and safety.</p>
                        </div>
                    </div>
                    <div class="col-md-6 d-flex align-items-stretch mt-4 mt-md-0" data-aos="fade-up" data-aos-delay="500">
                        <div class="icon-box">
                            <i class="bi bi-calendar4-week"></i>
                            <h4><a href="#">VISA APPLICATION</a></h4>
                            <p>We provide assistance in
                                securing travel documents
                                as well as advice and
                                process destination visa
                                upon request for clients. We
                                also process and issue all
                                Transit visas to Dubai for
                                clients</p>
                        </div>
                    </div>
                    <div class="col-md-6 d-flex align-items-stretch mt-4 mt-md-0" data-aos="fade-up" data-aos-delay="600">
                        <div class="icon-box">
                            <i class="bi bi-briefcase"></i>
                            <h4><a href="#">CAR HIRE</a></h4>
                            <p>We offer ground
                                transportation and logistics
                                services to our clients with
                                our variety of cars available to
                                suit client preferance and
                                needs.
                            </p>
                        </div>
                    </div>
                </div>

            </div>
        </section><!-- End Services Section -->


    </main>
@endsection
