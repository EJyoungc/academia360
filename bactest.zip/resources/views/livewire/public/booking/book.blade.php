<div>
    {{-- Do your work, then step back. --}}
    <section id="hero2" style="background: url('../img/hero-bg.jpg') top center;"
        class="d-flex justify-cntent-center align-items-center">
        <div class="container">
            <div class="row justify-content-center" data-aos="fade-up">
                <div class="col-md-7  text-white text-center ">
                    <div class=" fw-bold display-1 ">Booking</div>
                    <p>

                    </p>
                </div>
            </div>
        </div>
    </section><!-- End Hero -->
    <main id="main" class="margin-top-100">
        <section>
            <div class="container-fluid ">
                <div class="row justify-content-center">
                    <div class="col-md-10   ">
                        <div class="card shadow-lg bg-light border-0 rounded-4 ">
                            <div class="card-body">

                                <div class="d-flex ">
                                    <div class=" border-end border-1 mt-5 p-1 border-white w-100 flex-sm-fill ">
                                        {{-- <h4 class="text-center">listing</h4> --}}


                                        <div class="text-center">
                                            @if ($listing->image)
                                                <img src="{{ url('storage/'. $listing->image) }}" width="130"
                                                    height="130" alt="" srcset="">
                                                <br>
                                                <a href="{{ url('storage/' . $listing->image) }}"
                                                    data-gallery="portfolioGallery"
                                                    class="portfolio-lightbox preview-link"
                                                    title="{{ $listing->name }}"><i class="ri-eye-fill"> view</i></a>
                                                <p class="text-wrap">
                                            @endif
                                            {{-- {{ $listing }} --}}
                                            <br>
                                            @if ($listing->package->category->id == '1')
                                                {{ $listing->room_type }} <br>
                                                {{ $listing->description }} <br>
                                                {{ 'MKW' . $listing->price }}
                                            @elseif ($listing->package->category->id == '2')
                                                <img src="{{ asset('storage/', $listing->package->image->image) }}"
                                                    width="130" height="130" alt="" srcset="">
                                                <br>
                                                <a href="{{ url('storage/' . $listing->package->image->image) }}"
                                                    data-gallery="portfolioGallery"
                                                    class="portfolio-lightbox preview-link"
                                                    title="{{ $listing->name }}"><i class="ri-eye-fill"> view</i></a>
                                                <p class="text-wrap">
                                                    @if ($listing->flight_international == '')
                                                        <h6>{{ $listing->from->name }} - {{ $listing->to->name }}</h6>
                                                    @else
                                                        <h6>{{ $listing->ifrom->name }} - {{ $listing->ito->name }}
                                                        </h6>
                                                    @endif
                                                <h6>{{ $listing->flight_departure }} - {{ $listing->flight_arrival }}
                                                </h6>
                                                <h6>{{ $listing->package->name }}</h6>
                                                <br>
                                                MKW {{ $listing->price }}.00
                                            @elseif($listing->package->category->id == '3')
                                                <h6>{{ $listing->package->name }}</h6>
                                                <h6>{{ $listing->description }}</h6>
                                                <h6 class="fw-bold">MWK {{ $listing->price }}.00</h6>
                                            @elseif($listing->package->category->id == '4')
                                                <img src="{{ url('storage/'. $listing->package->image->image) }}"
                                                    width="130" height="130" alt="" srcset="">
                                                <br>
                                                <a href="{{ url('storage/' . $listing->package->image->image) }}"
                                                    data-gallery="portfolioGallery"
                                                    class="portfolio-lightbox preview-link"
                                                    title="{{ $listing->name }}"><i class="ri-eye-fill"> view</i></a>
                                                <p class="text-wrap">
                                                <h6 class="fw-bold">{{ $listing->package->name }}</h6>
                                                <h6>{{ $listing->taxi_driver_name }}</h6>
                                                <h6>MWK {{ $listing->price }}.00</h6>
                                            @else
                                                {{ $listing->car_rental_type }} <br>
                                                {{ $listing->package->name }} <br>
                                                {{ $listing->package->district->name }} <br>
                                                {{ $listing->description }} <br>
                                                {{ $listing->taxi_driver_name }} <br>

                                                <span class="fw-bold">{{ 'MKW ' . $listing->price }} .00</span>
                                            @endif


                                            </p>
                                        </div>


                                    </div>
                                    <div
                                        class=" border-start border-1 pt-3 pe-4 ps-4 border-white w-100  flex-sm-fill ">
                                        <h4 class="text-center">Payment Details</h4>


                                        @if ($payattempt)
                                            @if ($paid)
                                                <div class="alert alert-success alert-dismissible fade show"
                                                    role="alert">

                                                    <strong> Successfully</strong> paid
                                                    <br>transaction id
                                                    <br>date{{ now() }}

                                                </div>
                                            @else
                                                <div class="alert alert-warning alert-dismissible fade show"
                                                    role="alert">

                                                    <strong>Error</strong> payment failed
                                                </div>
                                            @endif
                                        @else
                                            <div>
                                                {{-- payment form --}}
                                                <div class="form-group">
                                                    <label for="">Owner Name</label>
                                                    <input type="text" wire: name="" class="form-control"
                                                        id="">
                                                </div>
                                                <div class="form-group">
                                                    <label for="">Card number</label>
                                                    <input type="text" name="" class="form-control"
                                                        id="">
                                                </div>
                                                <div class="form-group">
                                                    <label for="">CVV</label>
                                                    <input type="text" name="" class="form-control"
                                                        id="">
                                                </div>
                                                <div class="form-group">
                                                    <label for="">Month</label>
                                                    <input type="text" name="" class="form-control"
                                                        id="">
                                                </div>
                                                <div class="form-group">
                                                    <label for="">Year</label>
                                                    <input type="text" name="" class="form-control"
                                                        id="">
                                                </div>
                                                <div class="form-group">
                                                    <label for=""></label>
                                                    <a name="" id="" class="btn btn-dark form-control "
                                                        href="#" wire:click.prevent='pay' role="button"> <i
                                                            class="ri-bank-card-2-line"></i>Pay</a>
                                                </div>
                                            </div>
                                        @endif



                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

            </div>
        </section>
    </main>
</div>
