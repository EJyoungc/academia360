<div>
    {{-- Stop trying to control. --}}
    <x-jet-form-section submit="update">
        <x-slot name="title">
            {{ __('Update Mobile') }}
        </x-slot>

        <x-slot name="description">
            {{ __('Ensure your account is using a valid, working phone number.') }}
        </x-slot>

        <x-slot name="form">
            <div class="w-md-75">
                <div class="mb-3">
                @if ($mobileE)
                    <div class="alert alert-warning" role="alert">
                        <strong>warning</strong> {{$mobileE}}
                    </div>
                @endif
                    <x-jet-label for="mobile" value="{{ __('Current Mobile Number') }}" />
                    <x-jet-input id="mobile" type="text"
                        class="{{ $errors->has('mobile') ? 'is-invalid' : '' }}"
                        wire:model.defer="mobile" autocomplete="mobile number" />
                    <x-jet-input-error for="mobile" />
                </div>




            </div>
        </x-slot>

        <x-slot name="actions">
            <x-jet-button>
                <div wire:loading class="spinner-border spinner-border-sm" role="status">
                    <span class="visually-hidden">Loading...</span>
                </div>

                {{ __('Save') }}
            </x-jet-button>
        </x-slot>
    </x-jet-form-section>
</div>
