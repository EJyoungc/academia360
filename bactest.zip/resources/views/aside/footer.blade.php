<!-- ======= Footer ======= -->
<footer id="footer">

    {{-- <div class="footer-newsletter">
            <div class="container">
                <div class="row">
                    <div class="col-lg-6">
                        <h4>Our Newsletter</h4>
                        <p>Tamen quem nulla quae legam multos aute sint culpa legam noster magna</p>
                    </div>
                    <div class="col-lg-6">
                        <form action="" method="post">
                            <input type="email" name="email"><input type="submit" value="Subscribe">
                        </form>
                    </div>
                </div>
            </div>
        </div> --}}

    <div class="footer-top">
        <div class="container">
            <div class="row">

                <div class="col-lg-4 col-md-6 footer-links">
                    <h4>Useful Links</h4>
                    <ul>
                        <li><i class="bx bx-chevron-right"></i> <a href="{{ route('root.index') }}">Home</a></li>
                        <li><i class="bx bx-chevron-right"></i> <a href="{{ route('root.about') }}">About us</a></li>
                        <li><i class="bx bx-chevron-right"></i> <a href="{{ route('root.services') }}">Services</a></li>
                        <li><i class="bx bx-chevron-right"></i> <a href="{{ route('login') }}">Login</a></li>
                        <li><i class="bx bx-chevron-right"></i> <a href="{{ route('register') }}">Register</a></li>
                    </ul>
                </div>

                <div class="col-lg-4 col-md-6 footer-links">
                    <h4>Our Services</h4>
                    <ul>
                        <li><i class="bx bx-chevron-right"></i> <a href="{{ route('root.stays') }}">Stays</a></li>
                        <li><i class="bx bx-chevron-right"></i> <a href="{{ route('root.fights') }}">Flights</a></li>
                        <li><i class="bx bx-chevron-right"></i> <a href="{{ route('root.carrentals') }}">Car rentals</a>
                        </li>
                        <li><i class="bx bx-chevron-right"></i> <a
                                href="{{ route('root.attractions') }}">Attractions</a></li>
                        <li><i class="bx bx-chevron-right"></i> <a href="{{ route('root.airports') }}">Taxi</a></li>
                    </ul>
                </div>

                <div class="col-lg-4 col-md-6 footer-contact">
                    <h4>Contact Us</h4>
                    <p>
                        BCA Travel Limited <br>
                        P.O BOX 1967 <br>
                        Office 6,2nd floor,
                        European Business Center,
                        Area 3, Lilongwe. <br>
                        <strong>Phone:</strong> +265 984 901 590<br>
                        <strong>Phone:</strong> +265 992 734 108<br>
                        <strong>Email:</strong> info@abcatravel.com<br>
                        <strong>Email:</strong> bcatravelmalawi@gmail.com<br>
                    </p>

                </div>



            </div>
        </div>
    </div>

    <div class="container">
        <div class="copyright">
            &copy; Copyright <strong><span>BCA Travels</span></strong>. All Rights Reserved
        </div>
        <div class="credits">
            Designed by <a href="#">CoolEnterprises Malawi</a>
        </div>
    </div>
</footer><!-- End Footer -->
